# I3322 v27 Lower-Bound Re-Audit Bundle

This package is a refutation-first re-audit package for the **quantitative lower bound only**:
\[
S-S_d\ge c(1+d)^{-K}e^{-Cd},
\qquad
D_{\rm lower}(\varepsilon)=\Omega(\log(1/\varepsilon)).
\]

The live authority begins with:

- `new_docs/00_AUTHORITY_BANNER_V27.md`
- `new_docs/01_RAW_CELL_PARITY_EDGE_BUDGET.md`
- `new_docs/02_CELL_RESPONSE_AND_BRIDGE_RECURRENCE_V27.md`
- `new_docs/03_REPEATED_CELL_CYCLE_EXACTIFICATION_V27.md`
- `new_docs/04_STATE_CARRYING_COMMON_RETURN_AND_NEUTRAL_GAIN_V27.md`
- `new_docs/05_EXPONENTIAL_LOWER_ASSEMBLY_V27.md`
- `new_docs/10_LOWER_BOUND_PROMOTION_AUDIT_COMMISSION_V27.md`

The v25 component/CME route and the v26 authority layer are historical and superseded. v27 specifically repairs the reflection-boundary and partial-domain findings of the independent v26 audit. Constructive-upper files remain supplementary and outside the lower-bound promotion rule.
