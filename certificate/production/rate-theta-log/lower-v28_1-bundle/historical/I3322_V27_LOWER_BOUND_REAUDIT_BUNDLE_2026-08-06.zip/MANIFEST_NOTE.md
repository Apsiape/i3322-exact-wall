# Manifest convention — v27

The v27 release archive is accompanied by one **detached** JSON SHA-256 manifest containing the hash and size of every archive member plus the sealed archive hash. It is detached to avoid a circular self-hash dependency. Historical v23, consolidated-promotion, and v26 lower-bundle hashes are independently asserted by an executable guard inside the bundle.
