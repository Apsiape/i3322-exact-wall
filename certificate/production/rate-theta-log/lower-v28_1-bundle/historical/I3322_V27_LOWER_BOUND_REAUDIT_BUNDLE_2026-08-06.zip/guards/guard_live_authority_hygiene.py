#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]
new=root/'new_docs'
required=[
 '00_AUTHORITY_BANNER_V27.md',
 '01_RAW_CELL_PARITY_EDGE_BUDGET.md',
 '02_CELL_RESPONSE_AND_BRIDGE_RECURRENCE_V27.md',
 '03_REPEATED_CELL_CYCLE_EXACTIFICATION_V27.md',
 '04_STATE_CARRYING_COMMON_RETURN_AND_NEUTRAL_GAIN_V27.md',
 '05_EXPONENTIAL_LOWER_ASSEMBLY_V27.md',
 '06_P4_RECEIPTS_AND_SYMBOL_HYGIENE.md',
 '07_CORRECTION_AND_SUPERSESSION_LEDGER_V27.md',
 '08_P5_ARTIFACT_CLOSEOUT_V27.md',
 '09_TERMINAL_EVENT_TABLE_V27.md',
 '10_LOWER_BOUND_PROMOTION_AUDIT_COMMISSION_V27.md',
]
for n in required:
    assert (new/n).is_file(), n
proof='\n'.join((new/n).read_text() for n in required[1:6])
for bad in ['P(-u_k)','P(-t_k)','P(-u_j)','P(-t_j)','54\\varepsilon^{1/8}','N=\\lceil2/r\\rceil']:
    assert bad not in proof, bad
assert '128' in (new/'02_CELL_RESPONSE_AND_BRIDGE_RECURRENCE_V27.md').read_text()
assert 'local-error horn' in (new/'05_EXPONENTIAL_LOWER_ASSEMBLY_V27.md').read_text().lower()
print('PASS v27 live-authority hygiene')
