# Manifest convention

The release archive is accompanied by one detached JSON SHA-256 manifest containing the hash and size of every archive member plus the sealed archive hash. It is detached to avoid a circular self-hash dependency. Historical archive hashes are also asserted by an executable guard inside the bundle.
