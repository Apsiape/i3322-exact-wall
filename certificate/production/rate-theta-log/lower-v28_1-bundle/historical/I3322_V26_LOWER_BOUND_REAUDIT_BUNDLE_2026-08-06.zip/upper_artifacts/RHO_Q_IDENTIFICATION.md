# Endpoint Multiplier and Return-Distortion Identification

At the forward endpoint write
\[
a_+=r_B(\alpha),\qquad b_+=r_A(x_+),
\qquad
\rho_+=\frac{a_+}{b_+}.
\]
The tail theorem proves \(\lambda_j\to0\), hence \(0<\rho_+\le1\).

The distorted-return theorem orients its gain ratio into \((0,1]\):
\[
q_{\rm ret,+}:=\min\left\{\frac{a_+}{b_+},\frac{b_+}{a_+}\right\}.
\]
Because \(\rho_+\le1\),
\[
\boxed{q_{\rm ret,+}=\rho_+.}
\]
Therefore
\[
\boxed{\rho_+=1\iff q_{\rm ret,+}=1.}
\]
The same statement holds at the negative endpoint after reversing the outward orientation.

This is only an identification of the endpoint limiting datum with the exact return distortion variable. It does not supply the quarter ceiling; that comes from the already-promoted multiplicity-uniform neutral-return algebra.
