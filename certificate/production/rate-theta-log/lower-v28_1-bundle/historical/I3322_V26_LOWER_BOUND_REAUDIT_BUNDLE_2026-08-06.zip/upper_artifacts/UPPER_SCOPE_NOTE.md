# Upper-Bound Scope Note

The files in `upper_artifacts/` are shipped solely to close the v25 missing-artifact ledger. They are **not gates in Commission v26-L** and cannot promote the lower bound.

The live hygiene correction is:
\[
\lambda_j\to0\quad\Longrightarrow\quad\rho_\pm\le1,
\]
then equality \(\rho_\pm=1\) is excluded by the neutral-return quarter ceiling. The older prose "square summability gives \(\rho_\pm\le1\)" is understood only through the intermediate consequence \(\ell^2\Rightarrow\lambda_j\to0\).
