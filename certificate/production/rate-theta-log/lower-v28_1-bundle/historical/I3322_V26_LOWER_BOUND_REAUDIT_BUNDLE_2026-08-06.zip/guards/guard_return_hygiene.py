#!/usr/bin/env python3
"""Exact algebra guards for v26 return/hygiene conventions; not theorem verifiers."""
from fractions import Fraction

# Distorted return F(q) and neutral member.
def F(q): return (1+q)**2/(16*q)
assert F(Fraction(1)) == Fraction(1,4)
q0=Fraction(889,1000)
Slo=Fraction(2508753845015185,10**16)
gap=Slo-F(q0)
assert gap == Fraction(16308643699893,1778000000000000000) and gap>0

# rho/q endpoint identification after orientation rho<=1.
for k in range(1,1001):
    rho=Fraction(k,1000)
    q=min(rho,1/rho)
    assert q==rho
    assert (rho==1)==(q==1)

# State-level neutral-gain norm algebra: same nonzero source/destination and isometries.
for a_num in range(1,20):
    v=Fraction(a_num,7)
    w=Fraction(a_num+3,11)
    alpha=v/w
    beta=v/w
    assert alpha*w==v and beta*w==v and alpha==beta

print('PASS return/hygiene exact guards')
print('  F(1)=1/4')
print('  S_- - F(889/1000)=', gap)
print('  rho<=1 => q_oriented=rho checked on 1000 rationals')
