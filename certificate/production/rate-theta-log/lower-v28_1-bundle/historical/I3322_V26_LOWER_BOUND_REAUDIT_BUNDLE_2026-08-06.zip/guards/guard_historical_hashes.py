#!/usr/bin/env python3
"""Assert historical archive hashes used for provenance."""
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
v23=root/'historical/current-S-antitone-walk-v23.ORIGINAL.zip'
prior=root/'historical/I3322_CONSOLIDATED_PROMOTION_BUNDLE_2026-08-06.zip'
exp_v23='705c3dc4a3d090954c3bca220842c08e316c4a9ebc50f1f9cff69628ea7cc420'
exp_prior='06cc24c0da33d7f7b88e4ab9c945010a0a55ef19f88b5b611fd1021b0decf6ef'
assert sha(v23)==exp_v23
assert sha(prior)==exp_prior
print('PASS historical hash assertions')
print('  v23=',exp_v23)
print('  prior consolidated=',exp_prior)
