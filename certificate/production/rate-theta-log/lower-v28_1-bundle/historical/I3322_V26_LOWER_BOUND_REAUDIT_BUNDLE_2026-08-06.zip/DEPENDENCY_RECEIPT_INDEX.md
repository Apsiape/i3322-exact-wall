# Dependency / Receipt Index — v26 Lower Re-Audit

## Live lower-bound dependencies

- `THEOREM_N_SIGNED_PUBLIC_STATEMENT.md` — promoted qualitative wall and certified interval.
- `THEOREM_N_ROUND3_BLIND_AUDIT_SOURCE.md` — multiplicity-uniform equality-kernel/quarter algebra provenance.
- `CANONICAL_CRITICAL_STORAGE_AND_ANCESTRY.md` — canonical near-critical storage comparison and uniform convergence.
- `CRITICAL_ZERO_SET_REDUCTION_FOR_THEOREM_N.md` — zero-set localization and reflection gluing.
- `CONVEX_ENVELOPE_PLATEAU_EXCLUSION_AND_THEOREM_N_COMPLETION.md` — strict one-to-one increasing zero graph.
- `SHIFTED_GRID_RANK_COSTED_CLUSTERING_AND_COARSE_CONVERSE.md` — **only** its inversion-energy / far-inversion-cover material is consumed by v26; component clustering is not.
- `SHIFTED_GRID_RESPONSE_INTERFACE_REPAIR_V22.md` — restriction-free response budgets, bridge provenance, sink service.
- `INCOMING_OWNERSHIP_AND_TYPED_RECURRENCE_V23.md` — global one-step residual ownership / corridor constants.
- `PROJECTED_RETURN_MISMATCH_R1_V23.md` — distorted-return service only.
- `DISTORTED_RETURN_QUARTER_CEILING_CURRENT_V22.md` — exact return family and neutral member.
- `REFLECTION_DUAL_UPPER_ENVELOPE_AND_ADAPTIVE_TAILS.md` — endpoint-line certificate source.

## Historical / non-load-bearing dependencies

- `TOP_D_SIMULTANEOUS_MONOTONE_CLUSTERING_V23.md` — correction-history provenance only.
- `ANTITONE_EDGE_BUDGET_AND_EXPONENTIAL_BRANCH_SELECTION_V22.md` — historical only; supersession header attached.
- `CONSTRUCTIVE_LOG_UPPER_BOUND_V23.HISTORICAL.md` — upper historical text only.

## Supplementary upper-only dependencies

- `ENDPOINT_CESARO_CARRIER_RATE_THEOREM.md`
- `RANK_COSTED_PACKET_IDENTITY_AND_ALTERNATING_TRUNCATION.md`

The upper-only files do not participate in Commission v26-L promotion.
