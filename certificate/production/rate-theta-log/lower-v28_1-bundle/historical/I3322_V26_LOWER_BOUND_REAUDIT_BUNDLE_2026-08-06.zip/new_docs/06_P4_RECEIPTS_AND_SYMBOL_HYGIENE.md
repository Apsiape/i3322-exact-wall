# P4 Missing Receipts and Symbol Hygiene

## P4(a) finite near-maximizer R0 receipt

For \(q>S\),
\[
qI-\mathcal B=R_{0,q}+R_{A,q}+R_{B,q},\qquad R_{\nu,q}\succeq0.
\]
At Bell value \(S-\varepsilon\),
\[
\langle R_{0,q}\rangle\le q-S+\varepsilon.
\]
G1 gives \(g_S\ge m_g>0\) on the closed interval. Thus \(p_q=b_{\rm amp}^2/g_q\to p_S\) and then \(\phi_q\to\phi_S\) uniformly. Sending \(q\downarrow S\),
\[
\boxed{\langle R_{0,S}\rangle\le\varepsilon.}
\]
For a joint spectral projector \(Q=F(U)E(X)\), \([Q,R_{0,S}]=0\) because \(X\) and \(U\) commute and \(R_{0,S}=\phi_S(X,U)\). This commutation is **not** asserted for a general positive operator.

## P4(b) symbol typing

Use the following names in the v26 layer:

- \(b_{\rm amp}(t)=\sqrt{1-t^2}/2\) for the scalar amplitude factor;
- \(\iota(t)=-t\) for scalar reflection (never `b(t)=-t`);
- \(\xi_A^{\rm step},\xi_B^{\rm step}\) for live one-step response residual vectors;
- \(\xi_A^{\rm ret},\xi_B^{\rm ret}\) for fitted common-return residual vectors;
- \(e_{\rm ret}=\|\xi_A^{\rm ret}-q\xi_B^{\rm ret}\|\) for the live R1 mismatch;
- the **withdrawn** estimate on individual fitted-return residual norms remains withdrawn;
- \(\Gamma_j\) denotes prefix deterministic gain; `G_j` is not overloaded;
- \(m_C\) is minimum bridge amplitude; \(u_{\min}\) is a scalar minimum.

## P4(c) anchor

Retained joint mass \(\ge1/2\) spread over at most \(d\) occupied X marginal cells implies
\[
\boxed{z_0^2\ge1/(2d).}
\]
No component-rank ledger is used.

## Additional hygiene

1. `g >= 0` is inherited from positive Bellman storage; after G1, actually \(g_S\ge m_g>0\).
2. Ordering for collar continuity is: endpoint positivity \(\Rightarrow m_g>0\Rightarrow p_S\) continuous \(\Rightarrow\phi_S\) continuous \(\Rightarrow\) positive minimum on a closed collar disjoint from \(Z\).
3. Collar mass is paid by \(\mu({\rm collar})\le\langle R_0\rangle/c_0\le\varepsilon/c_0\).
4. The upper-tail proof uses \(\lambda_j\to0\) to rule out \(\rho_\pm>1\); square summability is only the upstream reason \(\lambda_j\to0\).
