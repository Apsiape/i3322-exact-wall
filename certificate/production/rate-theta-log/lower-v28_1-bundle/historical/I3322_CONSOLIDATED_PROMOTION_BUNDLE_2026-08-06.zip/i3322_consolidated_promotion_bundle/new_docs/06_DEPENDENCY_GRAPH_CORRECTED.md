# Corrected Dependency Graph — Consolidated Promotion Candidate

**Date:** 2026-08-06  
**Authority:** this graph supersedes the authority labels inside the historical v23 package for purposes of this promotion audit. Historical files remain verbatim evidence, not current status declarations.

## Legend

- `[P]` independently promoted / signed dependency.
- `[R]` proved or repaired receipt consumed by this candidate.
- `[C]` theorem candidate requiring the frozen promotion audit.
- `[A]` audit gate.
- `[X]` killed / retracted / withdrawn / retired as stated.

```text
[P] Theorem (N): finite-dimensional nonattainment, S>1/4
        |
        +------------------------------+
        |                              |
        v                              v
[P/R] canonical critical storage   [P/R] current positive weld / response identities
      + 3/2 Lipschitz                   + exact reflection supports
      + reflection gluing               + once-global X/U bridge
        |                              |
        v                              v
[R] endpoint-line inactivity       [R] shifted-grid joint ordering
    4039/100000, 9893/50000             + top-d recovery
    (provenance-specific)                N<=d, beta_tot<=32 eps^(1/8)
        |                              |
        v                              v
[R] G1 endpoint positivity          [R] incoming ownership + antitone support
    g(+/-1)>0                           + edge budget <=4d-2
        |                              + e^{-O(d)} branch attenuation
        v                              |
[R] conditional endpoint-product       |
    only for full-zero endpoint         |
    approaching sequences               |
        |                              |
        +------------+-----------------+
                     |
                     v
              [C] Cycle-Minimum Exactification (CME)
                     |
          +----------+-----------+
          |                      |
          v                      v
[A1/A4] marginal-to-joint    [A2] zero-graph/reflection
        at amplitude min           -> uniform o(1) tau pseudo-orbit
          |                      |
          +----------+-----------+
                     |
                     v
              [R] minimum-point pseudo-cycle lemma
                  increasing tau => approximate fixed point
                     |
                     v
              [A3] exact nonzero state-carrying
                   common-return limit
                     |
                     v
              [P/R] multiplicity-after-norms quarter ceiling
                     S <= 1/4
                     |
                     v
              contradiction with S>1/4
                     |
                     v
              [C] (m_C^amp)^2 <= C_C (eps+beta_tot)
                     |
                     v
              [A5] Section-7 prefix-product dichotomy
                     |
                     v
              [C] z_cyc^2 <= poly(d)e^{Cd}(eps+beta_tot)
                     |
                     v
              [R] abstract antitone terminal theorem
                     |
                     v
              [C] eps+beta_tot >= c poly(d)^{-1}e^{-Cd}
                     |
                     v
              [R] beta_tot <= 32 eps^(1/8)
                     |
                     v
              [C] S-S_d >= c0 poly(d)^{-1}e^{-C0 d}
                     |
                     v
              [C] D_lower(eps)=Omega(log(1/eps))
```

Constructive branch:

```text
[P/R] current spatial carrier
       |
       v
[R] G1 / conditional endpoint-product => full-zero closure compactly interior
       |
       v
[R] exact tail response multipliers satisfy 0<rho_+,rho_-<1
       |
       v
[R] alternating finite truncation + endpoint projectors
       |
       v
[R] D_upper(eps)=O(log(1/eps)) at existence-class strength
       |
       v
[C] D(eps)=Theta(log(1/eps))  -- only after A1-A5 all PASS
```

## Binding correction edges

```text
[X] GLOBAL ENDPOINT IDENTITY: g_S(1)g_S(-1)=0
      |
      +--> replaced by [R] endpoint positivity g_S(+/-1)>0
      +--> and [R] conditional statement:
           full-zero sequence -> endpoint  ==> endpoint product 0

[X] SEPARATE RETURN-ERROR LEMMA:
    ||r_A||^2+||r_B||^2 <= C(eps+beta_tot)
      |
      +--> not consumed by CME

[R, DEMOTED] R1: (1-q)z <= e_ret
      |
      +--> optional distorted-gain early service only
      +--> NOT neutral-cycle exactification

[X/RETIRED IF CME PASSES] old G2 packet-local Bell localization
      |
      +--> CME bypasses the noncommuting Bell cross-term localization problem

[X] old large-cycle "Monge horn"
      |
      +--> CME services all retained cycles; no separate reflected-cycle horn

[X] 13.2991468418 constructive coefficient
      |
      +--> upper result retained only as existential O(log(1/eps))
```

## Terminal-event table pointer

The authoritative terminal table is `07_TERMINAL_EVENT_TABLE.md`. No historical terminal split in v22/v23 overrides it.

## Promotion rule

`Theta(log)` promotes **iff** audit gates A1, A2, A3, A4, A5 each return a clean PASS. Any failure blocks promotion and becomes the first failed line. No partial score promotes the headline.
