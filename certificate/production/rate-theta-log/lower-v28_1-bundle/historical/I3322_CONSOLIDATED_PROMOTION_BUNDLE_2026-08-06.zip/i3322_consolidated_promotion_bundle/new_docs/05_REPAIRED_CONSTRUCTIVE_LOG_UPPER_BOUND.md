# Repaired Constructive Logarithmic Upper Bound

**Status:** **REPAIRED EXISTENCE-CLASS UPPER THEOREM.**  
**Supersedes only the endpoint-interiority argument in** `v23_package/CONSTRUCTIVE_LOG_UPPER_BOUND_V23.md`.

## 1. Correction

The original v23 upper document ruled out same-sign boundary closures using the now-killed unconditional identity

\[
g(1)g(-1)=0.
\]

That argument is withdrawn.

The replacement is stronger and simpler: `04_G1_ENDPOINT_POSITIVITY_AND_CONDITIONAL_ENDPOINT_PRODUCT.md` proves

\[
g(1)>0,
\qquad
g(-1)>0,
\]

and proves that **if a full-zero sequence approached either endpoint**, zero-set localization would force the endpoint product to vanish. Therefore the full-zero closure itself is compactly interior:

\[
\boxed{\overline Z\Subset(-1,1)^2.}
\tag{1.1}
\]

The exact spatial carrier is a bi-infinite full-zero carrier. Its tail and predecessor accumulation points therefore lie in one compact interior scalar corridor without any global endpoint-product axiom.

## 2. Strict tail contraction

The spatial carrier's limiting response coefficients are positive and finite on the compact tail closures. Let the two outward response multipliers be `rho_+`,`rho_->0`.

Square summability gives

\[
\rho_\pm\le1.
\]

If either multiplier were `1`, its exact tail closure would produce a neutral state-carrying return sector. The multiplicity-uniform common-return elimination would give

\[
S\le\frac14,
\]

contradicting `S>1/4`. Hence

\[
\boxed{0<\rho_+,\rho_-<1.}
\tag{2.1}
\]

Put

\[
\kappa_\pm=-\log\rho_\pm>0.
\]

The effective two-tail exponent is

\[
\boxed{
\kappa_{\rm eff}
=\left(\kappa_-^{-1}+\kappa_+^{-1}\right)^{-1}>0.
}
\tag{2.2}
\]

## 3. Finite truncation

Use a finite carrier interval `I=[-L,R] cap Z` and normalize the truncated Schmidt vector. Complete each severed alternating `2x2` local measurement block by a one-dimensional endpoint projector. The inherited truncation receipt then gives:

- all six local measurements remain projections;
- the truncated state is normalized;
- local dimension is `|I|+O(1)` (or exactly `|I|` under the inherited convention);
- all interior measurement blocks agree with the infinite carrier;
- value loss is bounded by omitted tail mass, omitted nearest-neighbor terms, and the two severed boundary bonds.

The geometric tail rates imply

\[
S-S_{d+O(1)}
\le
\exp[-\kappa_{\rm eff}d+o(d)].
\]

Therefore

\[
\boxed{
D_{\rm upper}(\varepsilon)=O(\log(1/\varepsilon)).
}
\]

## 4. Claim boundary

No decimal coefficient is promoted here. In particular the old `13.2991468418` coefficient remains retracted. This repair proves only the logarithmic **existence class** and removes the invalid global endpoint-product dependency.
