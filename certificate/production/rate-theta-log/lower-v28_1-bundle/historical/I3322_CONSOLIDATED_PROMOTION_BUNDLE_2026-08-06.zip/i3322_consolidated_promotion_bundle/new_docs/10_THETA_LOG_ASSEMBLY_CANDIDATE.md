# Quantitative Tail Assembly — `Theta(log)` Candidate

**Status:** **NOT PROMOTED.** Valid only after the five-scope CME promotion audit passes.

## 1. Lower branch after terminal service

The v23 top-`d` and antitone-walk package supplies:

\[
N\le d,
\qquad
\beta_{\rm tot}\le32\varepsilon^{1/8},
\]

an initial retained amplitude anchor of order `d^{-1/2}`, a total response-edge budget `<=4d-2`, and selected-branch deterministic attenuation only `e^{-O(d)}`.

G1 supplies fixed current coefficient bounds. Sink service is `O(E)`. CME plus the Section-7 comparison supplies repeated-cycle service

\[
z_{\rm cyc}^2\le\operatorname{poly}(d)e^{Cd}E,
\qquad
E:=\varepsilon+\beta_{\rm tot}.
\]

Therefore the abstract antitone terminal theorem yields

\[
\boxed{
E\ge c(1+d)^{-K}e^{-Cd}.
}
\tag{1.1}
\]

## 2. Exact `33 epsilon^(1/8)` assembly

For `0<epsilon<=1`,

\[
\varepsilon\le\varepsilon^{1/8}.
\]

Together with

\[
\beta_{\rm tot}\le32\varepsilon^{1/8},
\]

this gives

\[
\boxed{
E=\varepsilon+\beta_{\rm tot}
\le33\varepsilon^{1/8}.
}
\tag{2.1}
\]

Combining (1.1) and (2.1),

\[
33\varepsilon^{1/8}
\ge c(1+d)^{-K}e^{-Cd}.
\]

Raise both sides to the eighth power:

\[
\boxed{
\varepsilon
\ge
\left(\frac c{33}\right)^8
(1+d)^{-8K}e^{-8Cd}.
}
\tag{2.2}
\]

Thus, writing `epsilon=S-S_d`,

\[
\boxed{
S-S_d\ge c_0(1+d)^{-K_0}e^{-C_0d}.
}
\tag{2.3}
\]

and consequently

\[
\boxed{
D_{\rm lower}(\varepsilon)=\Omega(\log(1/\varepsilon)).
}
\]

## 3. Upper branch

`05_REPAIRED_CONSTRUCTIVE_LOG_UPPER_BOUND.md` gives

\[
D_{\rm upper}(\varepsilon)=O(\log(1/\varepsilon))
\]

without the killed global endpoint-product identity.

## 4. Promotion target

After, and only after, the CME promotion audit returns five PASS verdicts,

\[
\boxed{
D(\varepsilon)=\Theta(\log(1/\varepsilon)).
}
\]

becomes eligible for promotion at existence-class strength. No sharp lower base or equality with the constructive exponent is claimed.
