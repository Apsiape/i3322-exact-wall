# Promotion Audit Commission — Frozen Scope

**Action:** fire immediately on delivery.  
**Policy:** refutation-first; no promotion by plausibility, compactness rhetoric, or inherited status labels.

## Target claim

If all five gates below pass, promote the existence-class quantitative theorem

\[
S-S_d\ge\operatorname{poly}(d)^{-1}e^{-Cd},
\]

hence

\[
D_{\rm lower}(\varepsilon)=\Omega(\log(1/\varepsilon)),
\]

and, with the separately repaired constructive upper theorem,

\[
D(\varepsilon)=\Theta(\log(1/\varepsilon)).
\]

Nothing promotes before the audit closes.

## Gate 1 — marginal-to-joint convergence at the amplitude minimum

Attack the implication

\[
\frac{E_n}{(m_n^{\rm amp})^2}\to0
\]

plus

\[
\sum_v(z_v^2-w_v)\le C\beta_{\rm tot}
\]

implies a **uniform vertexwise** lower bound

\[
w_v\ge(m_n^{\rm amp})^2-o((m_n^{\rm amp})^2)
\]

for every vertex on the chosen cycle. Verify that the `z_v` and `w_v` refer to the same common paired labels and that no parity-family switch is hidden.

## Gate 2 — zero graph / reflection edges to a uniform pseudo-orbit

Verify that normalized `R_0` payment plus shrinking cells gives one cycle-uniform registration error, and that alternating exact reflected supports really produce

\[
|u_{k+1}-\tau(u_k)|\le\delta_n,
\qquad\delta_n\to0,
\]

for `tau=a o b` or its inverse. Do not accept a statement that separately controls Alice and Bob marginals without proving compatibility through the common joint labels.

## Gate 3 — exact state-carrying common-return limit

Verify that the scalar approximate fixed point selected by the minimum-point lemma is accompanied by nonvanishing normalized joint state and vanishing **individual response partition residuals** on the finitely many steps needed for one `tau` return. Check that the Hilbert ultraproduct/subsequence limit gives the exact component equations consumed by the multiplicity-uniform quarter-ceiling theorem.

## Gate 4 — two minima and uniform `delta`

Audit all occurrences of “minimum.” There are two unrelated objects:

1. `m_C^amp = min z_v`, used only as a normalization/mass floor;
2. `min u_k`, used only by the monotone pseudo-cycle lemma.

Verify that choosing the scalar-minimum vertex does not lose the amplitude lower bound, and that the pseudo-orbit error is a single `delta_n` valid around the whole cycle rather than an uncontrolled vertexwise family.

## Gate 5 — Section-7 exponential comparison and composition

Attack every exponent and prefix:

- `L<=2d`;
- `sum D_k<=4d-2`;
- every prefix degree product, not only the complete product;
- the `gamma_d` lower signal factor;
- the Green error factor `poly(d)e^{O(d)}`;
- the large-error / small-error dichotomy;
- the transfer from `m_C^amp` to the repeated anchor;
- insertion of `z_cyc^2<=poly(d)e^{Cd}E` into the branch theorem;
- final inversion using `beta_tot<=32 eps^(1/8)` and `E<=33 eps^(1/8)`.

## Required verdict form

For each gate output exactly one of:

- **PASS** — with the consumed receipt and the critical inequality named;
- **FAIL** — with the first false/unproved implication isolated;
- **CONDITIONAL** — only if a precise missing finite receipt is named.

A five-PASS result promotes the candidate. Any other result blocks promotion.
