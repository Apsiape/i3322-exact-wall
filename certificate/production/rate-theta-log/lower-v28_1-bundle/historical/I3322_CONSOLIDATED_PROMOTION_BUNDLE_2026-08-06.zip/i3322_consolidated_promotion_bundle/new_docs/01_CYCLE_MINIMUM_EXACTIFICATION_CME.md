# Cycle-Minimum Exactification (CME)

**Status:** **THEOREM CANDIDATE — promotion requires the frozen five-point audit.**  
**Purpose:** replace the old robust packet-Bell-localization gate with a cycle-normalization argument that preserves the exact response equations.

## 1. Setup and notation

Let a finite-dimensional near-maximizer have Bell deficit

\[
\varepsilon=S-\langle\mathcal B_{3322}\rangle,
\]

and let the v23 shifted-grid/top-`d` construction produce total paid deletion

\[
\beta_{\rm tot}\le32\varepsilon^{1/8}.
\]

Write

\[
E:=\varepsilon+\beta_{\rm tot}.
\]

Consider a directed rounded alternating response cycle `C` in the retained common label graph. At each cycle vertex `v`, let

\[
z_v>0
\]

be the relevant **marginal packet amplitude**. Define the amplitude minimum

\[
\boxed{
m_C^{\rm amp}:=\min_{v\in C}z_v.
}
\]

This quantity must not be confused with the minimum scalar coordinate used later in the order lemma.

Let `w_v` denote the matched joint-block mass associated with the same common label. The current marginal/joint typing receipt gives

\[
w_v\le z_v^2,
\]

and one-time accounting

\[
\sum_v(z_v^2-w_v)\le C_\beta\beta_{\rm tot}.
\]

The response partition identities have global squared error `O(epsilon)` and the shifted-grid scalar cell width tends to zero with `epsilon`.

## 2. CME statement

There is an existential constant `C_C<infinity`, independent of local dimension, cycle length, and fibre multiplicity, such that every retained rounded response cycle satisfies

\[
\boxed{
(m_C^{\rm amp})^2\le C_C E.
}
\tag{CME}
\]

The proof below is a contradiction/exactification argument. The three limiting interfaces identified in the promotion audit remain the only promotion-sensitive steps.

## 3. Contradiction normalization

Assume CME fails. Then there is a sequence of finite-dimensional near-maximizers and retained cycles such that

\[
\frac{E_n}{(m_n^{\rm amp})^2}\longrightarrow0.
\tag{3.1}
\]

Since every cycle amplitude is at least `m_n^amp`, the whole cycle survives normalization; there is no packet on the cycle whose state mass disappears relative to the normalization scale.

The once-global marginal-to-joint accounting gives, vertexwise,

\[
0\le z_{v,n}^2-w_{v,n}
\le C_\beta\beta_{{\rm tot},n}
=o((m_n^{\rm amp})^2).
\]

Hence uniformly over all vertices of the cycle,

\[
\boxed{
w_{v,n}\ge (m_n^{\rm amp})^2-o((m_n^{\rm amp})^2).
}
\tag{3.2}
\]

This is the load-bearing marginal-to-joint conversion attacked by audit item 1.

## 4. Uniform registration to the current zero graph

On every matched joint block the positive scalar remainder contributes nonnegative energy. Therefore

\[
0\le
\langle Q_{v,n}\psi_n,R_0Q_{v,n}\psi_n\rangle
\le\varepsilon_n.
\]

Combining with (3.2), the block-normalized scalar defect tends to zero **uniformly around the entire cycle**:

\[
\sup_{v\in C_n}
\frac{\langle Q_{v,n}\psi_n,R_0Q_{v,n}\psi_n\rangle}{w_{v,n}}
\longrightarrow0.
\tag{4.1}
\]

G1 supplies one fixed compact interior scalar corridor. On that compact set the continuous current remainder `R_0(x,u)` has zero set

\[
Z=\{(P(u),u)\}
\]

a one-to-one strictly increasing graph.

Define the compact scalar registration modulus

\[
\Omega(s):=
\sup\{\operatorname{dist}((x,u),Z):R_0(x,u)\le s\}.
\]

Then `Omega(s)->0` as `s->0`. Together with the shrinking shifted-grid width, (4.1) yields one scalar number

\[
\delta_n\downarrow0
\]

such that **every** cycle vertex is within `delta_n` of `Z`, and every ideal response edge is within `delta_n` of its exact scalar-reflection relation.

This uniform `delta_n`, rather than a vertex-dependent error, is the bookkeeping point attacked by audit item 4.

## 5. From reflection edges to a pseudo-orbit of `tau`

On the exact zero graph write `x=P(u)`. The two exact scalar response transformations are

\[
b(u)=-u,
\qquad
 a(u)=P^{-1}(-P(u)).
\]

On their common invariant domain they are decreasing involutions, so

\[
\tau=a\circ b
\]

is increasing. Reversing orientation replaces `tau` by `tau^{-1}`, also increasing.

The exact reflected-support receipts say that an Alice ideal edge reflects the `X` scalar support and a Bob ideal edge reflects the `U` scalar support. Since every cycle vertex is uniformly `delta_n`-registered to the same strict zero graph, two successive alternating edges give, after choosing one parity and orientation,

\[
\boxed{
|u_{k+1,n}-\tau(u_{k,n})|\le\widetilde\delta_n,
\qquad
\widetilde\delta_n\to0,
}
\tag{5.1}
\]

uniformly around the same-parity cyclic word.

No Bell-operator compression or packet-local Bell deficit is used here. This is audit item 2.

## 6. Minimum-point exactification

Apply `02_MINIMUM_POINT_PSEUDOCYCLE_LEMMA.md` to the cyclic pseudo-orbit (5.1). Let

\[
u_{j_n,n}=\min_k u_{k,n}
\]

be the **minimum scalar coordinate** on the same-parity cycle. Then

\[
|\tau(u_{j_n,n})-u_{j_n,n}|
\le\widetilde\delta_n
\longrightarrow0.
\]

After passing to a subsequence inside the fixed compact corridor,

\[
 u_{j_n,n}\to u_*,
\qquad
\boxed{\tau(u_*)=u_*.}
\tag{6.1}
\]

The scalar minimum `u_{j_n,n}` and the amplitude minimum `m_n^amp` play completely different roles. The chosen scalar-minimum vertex nevertheless has amplitude at least `m_n^amp`, so all normalized response residual estimates below remain valid there.

## 7. State-carrying common-return limit

At the scalar-minimum vertex and the finitely many response steps needed to realize one `tau` step, every relevant marginal amplitude is at least `m_n^amp`. The restriction-free Alice/Bob response partition identities have squared residual `O(epsilon_n)`, hence their residuals divided by `m_n^amp` tend to zero by (3.1).

The same is true of the marginal-to-joint discrepancy because `beta_tot,n/(m_n^amp)^2 -> 0`.

Normalize the corresponding joint packet vectors. Passing to a Hilbert ultraproduct (or an equivalent subsequential exact norm-equation limit) yields a nonzero vector carrying:

1. an exact zero-graph pair `(x_*,u_*)`, `x_*=P(u_*)`;
2. the exact response equations for both alternating kernels;
3. the fixed-return relation `tau(u_*)=u_*`.

Since `a,b` are involutions, `tau(u_*)=u_*` implies

\[
a(u_*)=b(u_*)=-u_*.
\]

Equivalently,

\[
P(-u_*)=-x_*.
\]

Thus both

\[
(x_*,u_*),
\qquad
(-x_*,-u_*)
\]

are exact full-zero pairs and the limiting vector is a **state-carrying exact common-return sector**.

This is audit item 3. It is the point at which the minimum-amplitude normalization is essential: the old scalar compactness argument did not preserve a nonzero response state.

## 8. Multiplicity-uniform quarter ceiling

The promoted equality-kernel mechanism reduces the exact common-return response equations to scalar norm-ratio equations between complete fibres. Arbitrary finite fibre multiplicity disappears after taking norms; no rank-one fibre hypothesis is used.

For the exact common-return ratio `rho>0`, zero-set localization gives

\[
S-d(x_*,u_*)
=\rho\bigl(b(x_*)+b(u_*)\bigr),
\]

\[
S-d(-x_*,-u_*)
=\rho^{-1}\bigl(b(x_*)+b(u_*)\bigr).
\]

The audited multiplicity-uniform elimination gives

\[
\boxed{S\le\frac14.}
\]

But the certified lower strategy gives

\[
S>0.2508753845015185>\frac14.
\]

Contradiction. Therefore (3.1) is impossible, proving CME at existence-class strength.

## 9. What CME does and does not prove

CME proves only the **cycle amplitude-minimum payment**

\[
(m_C^{\rm amp})^2\lesssim E.
\]

It does not by itself pay the repeated anchor chosen by the v23 branch walk. That transfer is performed separately in `03_EXPONENTIAL_COMPARISON_FROM_CYCLE_MIN_TO_REPEATED_ANCHOR.md` and is allowed to lose `e^{O(d)}`.

CME does not use R1, does not prove the withdrawn separate-error lemma, and does not localize the Bell operator to a packet.
