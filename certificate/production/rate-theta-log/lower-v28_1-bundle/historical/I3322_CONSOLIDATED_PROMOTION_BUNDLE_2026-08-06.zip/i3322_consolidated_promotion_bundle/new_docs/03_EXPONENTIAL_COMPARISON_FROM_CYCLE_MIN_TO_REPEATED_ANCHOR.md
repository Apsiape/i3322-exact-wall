# Section 7 Repair — Exponential Comparison from Cycle Minimum to Repeated Anchor

**Status:** **DERIVED CANDIDATE; audit item 5.**  
**Purpose:** convert CME's dimension-independent amplitude-minimum payment into the `e^{O(d)}` repeated-anchor cycle service sufficient for the v23 branch theorem.

## 1. Inputs

Along a simple selected alternating walk/cycle, v23 gives

\[
z_{k+1}\ge g_kz_k-e_k,
\qquad
 g_k=\frac{\sigma}{\sqrt{D_k}},
\]

with fixed `sigma>0` from G1,

\[
\sum e_k^2\le C_R E,
\qquad
E=\varepsilon+\beta_{\rm tot},
\]

and

\[
L\le2d,
\qquad
\sum_{k=0}^{L-1}D_k\le4d-2.
\]

Put

\[
\bar\sigma=\min(1,\sigma),
\]

\[
\boxed{
\gamma_d:=2^{-2d+1}\bar\sigma^{2d}.
}
\tag{1.1}
\]

For every prefix of the walk,

\[
\prod D_k^{-1/2}\ge2^{-2d+1},
\]

and the `sigma` factors contribute at least `bar sigma^(2d)`. Hence every deterministic prefix product obeys

\[
\boxed{G_j:=\prod_{k<j}g_k\ge\gamma_d.}
\tag{1.2}
\]

Also `g_k<=A` for one fixed corridor constant `A`, so the forward Green error factor satisfies

\[
\mathcal H_d\le\sqrt{2d}\,\max(1,A)^{2d}=\operatorname{poly}(d)e^{O(d)}.
\tag{1.3}
\]

## 2. Prefix dichotomy

Let `z_cyc` be the repeated-anchor amplitude at the start of the closed segment. Iterating the recurrence to any cycle vertex gives

\[
z_j\ge G_jz_{\rm cyc}-\mathcal H_d\sqrt{C_RE}.
\]

There are two alternatives.

### Alternative A — accumulated response error is already large

If

\[
\mathcal H_d\sqrt{C_RE}
\ge\frac12\gamma_dz_{\rm cyc},
\]

then

\[
\boxed{
E\ge
\frac{\gamma_d^2}{4C_R\mathcal H_d^2}
 z_{\rm cyc}^2.
}
\tag{2.1}
\]

The coefficient on the right is `poly(d)^(-1)e^{-O(d)}`. Thus the repeated anchor is already paid at the exponential class needed by the final theorem.

### Alternative B — every cycle packet stays large

Otherwise, for every cycle prefix,

\[
z_j\ge\frac12\gamma_dz_{\rm cyc}.
\]

Hence the amplitude minimum obeys

\[
\boxed{
m_C^{\rm amp}\ge\frac12\gamma_dz_{\rm cyc}.}
\tag{2.2}
\]

CME gives

\[
(m_C^{\rm amp})^2\le C_CE.
\]

Combining with (2.2),

\[
\boxed{
z_{\rm cyc}^2
\le4C_C\gamma_d^{-2}E.
}
\tag{2.3}
\]

Again `gamma_d^(-2)=e^{O(d)}` with only fixed corridor constants.

## 3. Unified cycle service

The two alternatives yield finite constants `C,K,C_0` such that

\[
\boxed{
z_{\rm cyc}^2
\le C(1+d)^K e^{C_0d}
(\varepsilon+\beta_{\rm tot}).
}
\tag{3.1}
\]

This is weaker than the dimension-independent G2 service originally requested by v23, but the abstract antitone branch theorem does not require a dimension-independent cycle constant. An `e^{O(d)}` terminal service merely changes the final exponential base.

## 4. Composition with the branch theorem

The retained graph has an anchor of squared amplitude at least `c_a/d`, the deterministic selected-branch attenuation is `e^{-O(d)}`, and all Green error factors are `e^{O(d)}`. Sink service is already `O(E)`. Replacing the old cycle hypothesis by (3.1) therefore yields

\[
\boxed{
E\ge c(1+d)^{-K_1}e^{-C_1d}.
}
\tag{4.1}
\]

The exact constants are intentionally not optimized.

## 5. Audit boundary

Audit item 5 should verify:

1. the prefix bound (1.2) is valid for **every prefix**, not only the complete cycle;
2. the Green error bound (1.3) uses only an upper corridor gain and `L<=2d`;
3. the same `z_cyc` is the repeated parity-state amplitude consumed by the branch theorem;
4. no unrecorded final edge is omitted;
5. inserting the `e^{O(d)}` service into the abstract terminal theorem preserves an overall `poly(d)^(-1)e^{-Cd}` lower payment.
