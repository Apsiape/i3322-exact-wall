# Consolidated Promotion Bundle — Authority Banner and Audit Scope

**Date:** 2026-08-06  
**Package status:** **PROMOTION CANDIDATE / AUDIT TRIGGER ONLY**  
**Frontier-work status:** frozen for this delivery.

## Binding authority boundary

Nothing in this bundle promotes the quantitative finite-dimensional tail theorem before the promotion audit completes.

The already-signed Theorem (N) remains independently promoted: finite-dimensional strategies do not attain the I3322 supremum `S`. The new quantitative target in this bundle is stronger:

\[
S-S_d\ge \operatorname{poly}(d)^{-1}e^{-Cd},
\qquad
D_{\rm lower}(\varepsilon)=\Omega(\log(1/\varepsilon)),
\]

and, after combination with the repaired constructive upper direction,

\[
D(\varepsilon)=\Theta(\log(1/\varepsilon)).
\]

Those statements are **THEOREM CANDIDATES**, not promoted results.

## Promotion audit: frozen scope

The audit fires on delivery and is restricted to these five load-bearing interfaces:

1. **Marginal-to-joint convergence at the amplitude-minimum packet.**
2. **Zero-graph/reflection edges to an `o(1)` pseudo-orbit of `tau`.**
3. **Passage to a nonzero exact state-carrying common-return limit.**
4. **Scalar-minimum versus amplitude-minimum bookkeeping, including one uniform pseudo-orbit error `delta` around the whole cycle.**
5. **Section-7 prefix-product dichotomy and composition of the resulting `e^{O(d)}` cycle service with the v23 branch theorem.**

A clean verdict on all five promotes the logarithmic lower class and therefore, together with the repaired upper theorem, the `Theta(log)` complexity class. Any failed item blocks promotion and becomes the first failed line.

## Binding correction notices

- **KILLED:** the unconditional/global identity
  \[
  g_S(1)g_S(-1)=0.
  \]
  It is not a theorem and must not be consumed anywhere in the promoted chain.

- **VALID CONDITIONAL REPLACEMENT:** if a sequence of full-zero labels approaches an endpoint, zero-set localization gives `K=1` along that sequence, hence continuity forces
  \[
  g_S(1)g_S(-1)=0.
  \]
  Endpoint positivity therefore excludes such a full-zero boundary sequence.

- **WITHDRAWN:** the proposed separate-return-error estimate
  \[
  \|r_A\|^2+\|r_B\|^2\lesssim\varepsilon+\beta_{\rm tot}.
  \]
  The available receipts do not prove it for the same fitted return datum.

- **R1 DEMOTED:** `PROJECTED_RETURN_MISMATCH_R1_V23.md` remains a sound distorted-gain service:
  \[
  (1-q)z\le e_{\rm ret}.
  \]
  It is not used to exactify neutral cycles in CME and is not a substitute for individual error control.

- **RETIRED IF CME PASSES:** the old G2 demand for packet-local Bell-operator localization of `F(q)`. CME is intended to bypass that noncommuting-cross-term problem rather than solve it.

## Historical-file warning

The delivered **full v23 package is preserved verbatim** for audit traceability. It contains historical files whose claims are superseded by this correction layer, including a dependency file using the now-killed global endpoint-product statement. The corrected dependency graph in `new_docs/06_DEPENDENCY_GRAPH_CORRECTED.md` controls authority for this promotion bundle.
