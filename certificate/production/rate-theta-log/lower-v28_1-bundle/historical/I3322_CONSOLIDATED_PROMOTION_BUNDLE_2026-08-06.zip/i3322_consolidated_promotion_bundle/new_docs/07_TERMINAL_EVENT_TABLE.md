# Corrected Terminal-Event Table

**Authority:** candidate endgame table for the promotion audit.

| Event reached by selected antitone walk | Service | Status / role |
|---|---|---|
| Boundary/collar mass before the walk | G1 fixed positive scalar remainder on a uniform endpoint collar | **Paid pre-processing; not a live terminal event** |
| Graph sink / deleted destination | Destination-localized response identity + once-global deletion/bridge budget | **Closed** |
| Repeated parity-state: accumulated recurrence error already comparable to selected signal | Section-7 Alternative A | **Direct `poly(d)^(-1)e^{-O(d)}` payment** |
| Repeated parity-state: recurrence error smaller than selected signal | Every cycle packet is `>= (gamma_d/2) z_cyc`; CME pays amplitude minimum | **CME + Section-7 Alternative B** |
| Return with visibly distorted fitted gain `q<q_0` | R1: `(1-q)z <= e_ret` | **Optional early service only; R1 is demoted to distorted-gain service** |
| Neutral/almost-neutral cycle | **Do not invoke R1 + packet-local `F(q)` localization**; use CME | **Old G2 route retired if CME passes** |
| Large reflected/non-Monge cycle | CME is global over retained cycles; no separate “large cycle => inversion” horn | **No Monge horn required** |

## Binding correction

The final cycle payment is not required to be dimension-independent. The branch theorem tolerates

\[
z_{\rm cyc}^2\le e^{O(d)}E,
\]

because the selected signal itself is only `e^{-O(d)}` after at most `2d` parity states. This is the reason CME's dimension-independent **cycle-minimum** payment is sufficient after Section 7.
