# Minimum-Point Pseudo-Cycle Lemma

**Status:** **PROVED — elementary order lemma.**  
**Role:** dimension-free scalar core of Cycle-Minimum Exactification.

## Theorem

Let `tau:I->I` be increasing on a totally ordered interval. Let

\[
u_0,u_1,\ldots,u_{L-1},\qquad u_L=u_0,
\]

be a cyclic `delta`-pseudo-orbit:

\[
|u_{k+1}-\tau(u_k)|\le\delta
\qquad (k\bmod L).
\]

Then the cycle contains a point `u_j` satisfying

\[
\boxed{|\tau(u_j)-u_j|\le\delta.}
\]

In fact any occurrence of a minimum scalar value on the cycle has this property.

## Proof

Choose `j` such that

\[
u_j=\min_k u_k.
\]

Since `u_{j+1}>=u_j`, the pseudo-orbit inequality gives

\[
\tau(u_j)\ge u_{j+1}-\delta\ge u_j-\delta.
\]

Also `u_{j-1}>=u_j`. Monotonicity therefore gives

\[
\tau(u_j)\le\tau(u_{j-1}).
\]

But

\[
|u_j-\tau(u_{j-1})|\le\delta,
\]

so

\[
\tau(u_j)\le u_j+\delta.
\]

Combining the two inequalities,

\[
\boxed{u_j-\delta\le\tau(u_j)\le u_j+\delta.}
\]

No cycle-length, rank, dimension, differentiability, invertibility, or compactness constant appears. ∎

## Scope guard

The `minimum` in this lemma is a **minimum scalar coordinate**. It is not the amplitude minimum used in CME. The promotion audit must keep these two minima typed separately.

## Finite guard

`guards/guard_minimum_point_pseudocycle.py` exhaustively enumerates nondecreasing maps and all cyclic words on grids of size `2..5` and verifies the theorem using exact integer arithmetic.
