# I3322 Consolidated Promotion Bundle — CME / v23 Quantitative Tail

**Delivery date:** 2026-08-06  
**Status:** **promotion candidate; audit trigger; no quantitative promotion yet.**

This bundle freezes the current quantitative-tail route and delivers it for refutation-first promotion audit. It intentionally contains the complete historical v23 package **verbatim**, including superseded status language, together with a corrected authority layer that controls all current claims.

## Read first

1. `new_docs/00_AUTHORITY_BANNER_AND_AUDIT_SCOPE.md`
2. `new_docs/06_DEPENDENCY_GRAPH_CORRECTED.md`
3. `new_docs/09_PROMOTION_AUDIT_COMMISSION.md`
4. `new_docs/08_ENDPOINT_RECEIPT_PROVENANCE.md`

## New candidate chain

- `01_CYCLE_MINIMUM_EXACTIFICATION_CME.md`
- `02_MINIMUM_POINT_PSEUDOCYCLE_LEMMA.md`
- `03_EXPONENTIAL_COMPARISON_FROM_CYCLE_MIN_TO_REPEATED_ANCHOR.md`
- `04_G1_ENDPOINT_POSITIVITY_AND_CONDITIONAL_ENDPOINT_PRODUCT.md`
- `05_REPAIRED_CONSTRUCTIVE_LOG_UPPER_BOUND.md`
- `07_TERMINAL_EVENT_TABLE.md`
- `10_THETA_LOG_ASSEMBLY_CANDIDATE.md`

## Historical v23 package

`v23_package/` is the complete extracted v23 package. `v23_package/current-S-antitone-walk-v23.ORIGINAL.zip` is the original archive, whose SHA-256 is

`705c3dc4a3d090954c3bca220842c08e316c4a9ebc50f1f9cff69628ea7cc420`.

Historical claims in that directory do not override the corrected authority layer.

## Dependency copies

`dependencies/` contains the consumed receipts needed to audit the new chain without relying on memory or repository lookup. The endpoint rational families are separated explicitly in `new_docs/08_ENDPOINT_RECEIPT_PROVENANCE.md`.

## Guards

`guards/` contains exact-arithmetic / finite-enumeration guards. They are **guards of algebra and bookkeeping, not theorem verifiers**. The analytic promotion still depends on the five frozen audit interfaces.

## Promotion condition

The quantitative theorem

\[
S-S_d\ge \operatorname{poly}(d)^{-1}e^{-Cd},
\qquad
D(\varepsilon)=\Theta(\log(1/\varepsilon))
\]

remains a **THEOREM CANDIDATE** until all five audit gates in `09_PROMOTION_AUDIT_COMMISSION.md` receive clean PASS verdicts.
