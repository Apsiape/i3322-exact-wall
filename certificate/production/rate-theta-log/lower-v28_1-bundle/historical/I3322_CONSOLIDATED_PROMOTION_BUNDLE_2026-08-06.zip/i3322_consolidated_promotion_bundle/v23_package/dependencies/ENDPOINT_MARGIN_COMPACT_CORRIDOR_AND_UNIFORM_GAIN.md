# Endpoint-Margin Compact Corridor and Uniform Current-\(S\) Gain

**Date:** 2026-08-05  
**Status:** exact analytic theorem.  
**Depends on:** the current endpoint-line inactivity certificate, reflection gluing at the endpoints, the full-zero closure identities, and the existing mixed/cross-endpoint classification.

---

# 1. Endpoint data

Let \(g=g_S\) be the canonical current critical storage. The exact rational endpoint-line certificate proves, for every \(u\in[-1,1]\),

\[
g(u)
<
S+\frac12-\frac u2-\delta_+,
\qquad
\delta_+=\frac{4039}{100000},
\]

and

\[
g(u)
<
S+\frac32+\frac{3u}{2}-\delta_-,
\qquad
\delta_-=\frac{9893}{50000}.
\]

Evaluating at the matching endpoint targets gives

\[
\boxed{g(1)<S-\delta_+,}
\]

\[
\boxed{g(-1)<S-\delta_-.}
\]

The promoted endpoint-product receipt gives

\[
\boxed{g(1)g(-1)=0.}
\]

---

# 2. Same-sign corners are impossible

Suppose a full-zero response-tail closure reached a same-sign corner

\[
(x_\infty,u_\infty)=(\sigma,\sigma),
\qquad
\sigma\in\{-1,1\}.
\]

Since

\[
d(\sigma,\sigma)=0,
\]

the full-zero closure equality is

\[
\boxed{g(1)+g(-1)=S.}
\]

Together with

\[
g(1)g(-1)=0,
\]

this forces

\[
\{g(1),g(-1)\}=
\{0,S\}.
\]

But the endpoint-line certificate proves that neither endpoint value can equal \(S\):

\[
g(1)<S-\delta_+<S,
\]

\[
g(-1)<S-\delta_-<S.
\]

Contradiction.

## Theorem 2.1 — Corner Elimination

\[
\boxed{
\text{No full-zero response-tail closure reaches a same-sign physical corner.}
}
\]

This removes the corner branch retained in the earlier tail trichotomy.

---

# 3. All boundary closures are impossible

The inherited endpoint classification already proves:

1. a closure with exactly one endpoint coordinate is impossible by the uniform endpoint \(R_0\)-gap;
2. cross corners
   \[
   (1,-1),\quad(-1,1)
   \]
   are Bellman-infeasible;
3. Theorem 2.1 excludes the two same-sign corners.

Therefore the closure of the full interior zero graph contains no point of the boundary of the physical square.

Let

\[
Z
=
\{(P(u),u):\phi(P(u),u)=0\}
\subset(-1,1)^2
\]

and let \(\overline Z\) denote its closure in \([-1,1]^2\).

## Theorem 3.1 — Compact Interior Full-Zero Corridor

\[
\boxed{
\overline Z\Subset(-1,1)^2.
}
\]

Equivalently, there exists a current constant

\[
\delta_{\rm cor}>0
\]

such that every full-zero pair satisfies

\[
\boxed{
|x|\le1-\delta_{\rm cor},
\qquad
|u|\le1-\delta_{\rm cor}.
}
\]

### Proof

The current scalar remainder and the full-zero closure identities are continuous on interior points and have the certified endpoint extensions used in the endpoint classification. Hence \(\overline Z\) is closed in the compact square. Sections 2--3 show

\[
\overline Z\cap\partial([-1,1]^2)=\varnothing.
\]

A compact set disjoint from a closed boundary has positive distance from it. \(\square\)

The theorem is qualitative but unconditional. An explicit numerical value of \(\delta_{\rm cor}\) would require a quantitative endpoint-collar execution; no such value is claimed here.

---

# 4. Uniform coefficient bounds

Let

\[
K
=
\pi_1(\overline Z)\cup\pi_2(\overline Z)
\Subset(-1,1).
\]

On \(K\),

\[
b(t)=\frac{\sqrt{1-t^2}}2
\]

is continuous and strictly positive, while the canonical storage \(g(t)\) is continuous and strictly positive.

Define

\[
r_B(t)=\frac{g(t)}{b(t)}.
\]

Then there are constants

\[
0<r_-\le r_+<\infty
\]

such that

\[
\boxed{
r_-\le r_B(t)\le r_+
\qquad(t\in K).
}
\]

The current full-zero response identities give the reciprocal coefficient laws for the reflected response. Thus every one-step response coefficient occurring on a state-carrying exact component is bounded above and below by positive current constants.

For the normalized packet response inequalities of the restriction-free kernel, the same compactness gives constants

\[
0<a_-\le a_+<\infty,
\qquad
0<b_-\le b_+<\infty,
\]

and therefore a two-response lower gain

\[
\boxed{
\sigma_0>0.
}
\]

No historical shooting atlas or TT-030 rebind is used.

---

# 5. Uniform return-multiplier interval

Let \(\mathcal C\subset\overline Z\) be the compact set of response-fixed closure pairs. For \((x,u)\in\mathcal C\), put

\[
\chi(x,u)=r_B(x)r_B(u),
\]

and define the outward two-characteristic multiplier

\[
q(x,u)=\min\{\chi(x,u),\chi(x,u)^{-1}\}.
\]

Because \(r_B\) is continuous and bounded away from zero and infinity on \(K\),

\[
q:\mathcal C\to(0,1]
\]

is continuous and has a positive minimum:

\[
\boxed{
q_-:=\min_{\mathcal C}q>0.
}
\]

The quantitative quarter-ceiling theorem gives pointwise

\[
q<\frac{889}{1000}.
\]

Compactness strengthens this to a uniform strict upper bound

\[
\boxed{
0<q_-
\le q
\le q_+
<\frac{889}{1000}
}
\]

for some current \(q_+\).

## Corollary 5.1 — No Superexponential Current Tail

Every current response tail has a finite positive logarithmic exponent. The corner/superexponential alternatives in the previous carrier-rate trichotomy are empty for the current canonical wall.

For each parity tail,

\[
0<q_-
\le
\lim q_n
\le
q_+
<1.
\]

Hence its amplitude and boundary-flux profiles are genuinely exponential in response depth, bounded between two geometric rates.

---

# 6. Longitudinal profile for the universal converse

The two-sided variable-gain fundamental-domain theorem uses the infimal near-maximizer profile

\[
\underline\Gamma_d.
\]

The compact corridor makes all localized response coefficients uniformly bounded above and below. More precisely, after scalar mismatch and boundary-collar mass have been placed in the paid diagonalization remainder, every retained two-response gain satisfies

\[
0<a_*\le a_n^\pm\le A_*<\infty
\]

with constants independent of the strategy, packet index, and dimension.

For a depth-\(d\) window this gives

\[
G_k^\pm\ge a_*^k,
\]

while the Green norms in the variable-gain recurrence obey

\[
E_k^\pm
\le
\sqrt{k}\,\max(1,A_*)^k.
\]

Put

\[
\sigma_G
=
\frac{\min(1,a_*)}{\max(1,A_*)}
\in(0,1].
\]

If \(\sigma_G=1\), replace it by any fixed smaller positive number. The optimized response quotient therefore satisfies the elementary common bound

\[
\Gamma_d
\ge
(1+d)^{-1/2}\sigma_G^d.
\]

The complementary branch, in which a fixed amount of state mass lies outside the compact response corridor, is already paid by the positive scalar remainder. Therefore:

## Theorem 6.1 — Uniform Exponential Longitudinal Floor

There are current constants

\[
c_G>0,
\qquad
0<\sigma_G<1,
\qquad
r_G<\infty
\]

such that

\[
\boxed{
\underline\Gamma_d
\ge
c_G(1+d)^{-r_G}\sigma_G^d.
}
\]

One may take \(r_G=1/2\) at the abstract coefficient-bound level. This is an exponential-class statement; it does not identify the sharp exact-carrier products.

For the optimized two-tail allocation, if the two exact limiting squared-gain exponents are \(\kappa_-\) and \(\kappa_+\), the longitudinal exponent is their harmonic allocation

\[
\kappa_{\rm eff}
=
\left(
\frac1{\kappa_-}
+
\frac1{\kappa_+}
\right)^{-1}.
\]

The theorem proves a uniform exponential class without a historical rigidity rebind. The separate algebraic tail-closure theorem now locates the finite candidate closure radii and improves the exact-carrier multiplier bound, but subexponential comparison of arbitrary near-maximizer products with the exact carrier remains open.

---

# 7. Converse reduction to one geometric profile

Insert Theorem 6.1 into the corrected two-profile converse:

\[
S-S_d
\ge
c\frac{\underline\Gamma_d^2}{d}
\min\left\{
1,
\underline\Delta_d\!\left(
 c\frac{\underline\Gamma_d^2}{d\underline C_d}
\right)^2
\right\}.
\]

The longitudinal response profile is now controlled exponentially. Therefore the only unresolved asymptotic mechanism is scalar-domain compression:

\[
\boxed{
\underline\Delta_d(h).
}
\]

## Corollary 7.1 — One-Profile Current Converse Gate

The current universal lower-profile problem is reduced to a quantitative lower bound for the response-domain compression profile. Branching, rank-safe packet topology, corner-tail gain collapse, and the uniform response floor are no longer independent gates.

A bound of the form

\[
\underline\Delta_d(h)
\ge
\operatorname{poly}(d)^{-1}e^{-\beta d}h^q
\]

would immediately imply

\[
\boxed{
S-S_d\ge \operatorname{poly}(d)^{-1}e^{-Cd}
}
\]

and hence

\[
d=\Omega(\log(1/\varepsilon)).
\]

---

# 8. Corrected dependency ledger

## Now proved

- same-sign physical corner closures are impossible;
- all full-zero graph closures are uniformly interior;
- the current coefficient corridor is compact without a historical rigidity rebind;
- every state-carrying response gain has a uniform positive floor;
- all current carrier tails are finite-rate exponential tails;
- the universal converse longitudinal profile has an exponential lower class.

## Retired

- corner tails as a live current possibility;
- a TT-030 compact-corridor rebind as a prerequisite for the response floor;
- the uniform-gain receipt as an independent open theorem;
- the rank-preserving shifted-flow decomposition gate.

## Still open

- an explicit current value of the interior-corridor width;
- sharp current tail multipliers;
- a quantitative lower bound for \(\underline\Delta_d(h)\);
- removal or sharp evaluation of the scalar-compression tax;
- the final universal finite-dimensional lower exponent.

---

# 9. Claim boundary

The endpoint margins prove strict interiority but do not locate the tail endpoints. The resulting response-gain constants are existential current constants, not certified public decimals.

The theorem does not yet prove a logarithmic dimension lower bound by itself. That conclusion still requires a quantitative asymptotic bound for scalar response-domain compression.
