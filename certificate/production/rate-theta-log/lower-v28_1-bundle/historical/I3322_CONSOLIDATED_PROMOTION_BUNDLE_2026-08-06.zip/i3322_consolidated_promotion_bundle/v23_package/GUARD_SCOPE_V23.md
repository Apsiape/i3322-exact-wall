# Guard Scope — v23

The bundled `v23_repair_guards.py` checks only:

1. the **actual** \(\varepsilon^{1/8}\) order implication;
2. the repaired top-\(d\) retained-mass algebra over 20,000 exact-rational trials;
3. the R1 contraction inequality over 50,000 exact-rational scalar trials;
4. the exact rational \(F(889/1000)\) separation.

It does **not** advertise an exhaustive antitone-support enumeration to 9x9. The v22 internal guard was smaller; the commission reports that the independent auditors extended the antitone test to 9x9/N=4 with zero violations. v23 treats that as external audit evidence, not as a bundled executable claim.

The antitone edge theorem itself has an analytic proof and does not rely on enumeration.
