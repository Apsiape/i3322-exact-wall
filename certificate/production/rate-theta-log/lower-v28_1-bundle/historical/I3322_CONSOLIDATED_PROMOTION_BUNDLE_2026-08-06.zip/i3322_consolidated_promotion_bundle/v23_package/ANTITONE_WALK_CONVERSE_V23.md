# Antitone-Walk Exponential Converse — v23

**Date:** 2026-08-06  
**Status:** conditional theorem with exactly two open analytic gates.  
**No forest decomposition is asserted.**

## 1. Repaired structural chain

For a local-dimension-\(d\) near-maximizer of deficit \(\varepsilon\):

1. State-anchored Monge/inversion energy obeys \(\mathcal I\le4\varepsilon\).
2. Shifted-grid far-inversion deletion plus \(\eta=\varepsilon^{1/8}\) gives
   \[
   \beta_{\rm far}\le16\varepsilon^{1/8}.
   \]
3. The surviving joint conflict components are simultaneously strictly ordered in \(X\) and \(U\).
4. The true top-\(d\) matched-block theorem selects at most \(d\) components with total deletion
   \[
   \beta_{\rm tot}\le32\varepsilon^{1/8}.
   \]
5. Alice and Bob response supports are antitone on the same labels.
6. The total edge budget is at most \(4d-2\). A largest-component alternating walk therefore loses only
   \[
   \prod D_v^{-1/2}\ge2^{-2d+1}.
   \]
7. Incoming ownership gives the lawful recurrence
   \[
   z_{v_{k+1}}
   \ge
   \frac{\sigma}{\sqrt{D_{v_k}}}z_{v_k}-e_k,
   \qquad
   \sigma=b_0/A_{\max},
   \]
   with
   \[
   \sum e_k^2\le C(\varepsilon+\beta_{\rm tot}).
   \]
8. Graph sinks are paid by the same destination-localized response identity.
9. At a repeated state, one additional application of the recurrence gives the cycle-branch lower bound at the repeated packet itself; no unrecorded “last edge” is omitted.
10. The projected-return mismatch theorem gives
    \[
    (1-q)z\le e_{\rm ret}.
    \]
11. For \(q\ge889/1000\), the exact scalar theorem gives a return gap \(\Delta_{\rm ret}>0\), **conditional on robust Bell localization G2**.

## 2. Conditional exponential conclusion

Assume:

### G1 — Uniform endpoint corridor
There are fixed current constants \(b_0>0\), \(A_{\max}<\infty\) valid on every load-bearing retained walk, with all excluded endpoint/collar mass quantitatively serviced.

### G2 — Robust distorted-return localization
There is a rank-independent modulus and Bell-localization receipt implementing R2 of `ROBUST_DISTORTED_RETURN_LOCALIZATION_GATE_V23.md`.

Then every terminal branch of the simple antitone walk—sink, q-distorted return, or F(q)-serviced return—forces

\[
\varepsilon+\beta_{\rm tot}
\ge
c(1+d)^{-K}e^{-Cd}.
\tag{2.1}
\]

Since

\[
\beta_{\rm tot}\le32\varepsilon^{1/8},
\]

(2.1) implies, after raising the correct order inequality to the eighth power,

\[
\boxed{
S-S_d
\ge
c_0(1+d)^{-K_0}e^{-C_0d}.
}
\tag{2.2}
\]

Therefore, **conditional on G1+G2**,

\[
\boxed{
D_{\rm lower}(\varepsilon)=\Omega(\log(1/\varepsilon)).
}
\tag{2.3}
\]

Together with the separately repaired constructive upper theorem,

\[
D_{\rm upper}(\varepsilon)=O(\log(1/\varepsilon)),
\]

one would obtain

\[
D(\varepsilon)=\Theta(\log(1/\varepsilon)).
\]

## 3. Present authority boundary

Because G1 and G2 are not closed in v23,

\[
\boxed{
\textbf{the lower logarithmic converse is not promoted.}
}
\]

This document is a reduction theorem, not a proof of the final lower bound.
