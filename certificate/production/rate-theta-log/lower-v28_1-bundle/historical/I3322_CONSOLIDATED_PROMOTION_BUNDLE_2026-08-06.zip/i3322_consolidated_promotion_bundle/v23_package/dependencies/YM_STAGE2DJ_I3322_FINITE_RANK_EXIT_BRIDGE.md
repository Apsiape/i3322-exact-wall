# Yang–Mills Stage 2DJ — I3322 Positive-Remainder / Finite-Rank Exit Bridge

**Date:** 4 August 2026  
**Status:** **GREEN internally** for the abstract positive-remainder finite-rank exit theorem and its exact specialization to the Stage-2DI triangle-loss constant. **AMBER / open** for the two Yang–Mills hypotheses that make it operative: construction of the moving contact packets with a quantitative lower weight envelope, and proof that off-contact packet mass is serviced by the completed-triangle remainder. The private I3322 dimension lower bound is treated here as a supplied, accepted result; it was not independently replayed from the public repository because that proof has not yet been integrated there. This is not a continuum Yang–Mills existence or mass-gap proof.

---

## 1. Why the I3322 work is materially relevant

The public I3322 proof has the structure

\[
q_\ast I-\mathcal B
=
R_0+R_A+R_B,
\qquad
R_\nu\succeq0,
\]

followed by an equality/contact analysis on spectral support.

The private quantitative strengthening adds the missing robust layer:

\[
\boxed{
\text{positive remainder}
\rightarrow
\text{contact packets}
\rightarrow
\text{finite-rank exit}
\rightarrow
\text{dimension-dependent deficit}.
}
\]

That is exactly the layer missing from the present Yang–Mills selector program.

Stage 2DI already supplies a positive local remainder. For every completed attachment triangle,

\[
\|L_\triangle\|
<
\eta_\triangle,
\qquad
\eta_\triangle=\frac{497}{500},
\]

so

\[
\boxed{
\mathcal D_\triangle
:=
I-L_\triangle^\ast L_\triangle
\succeq
\delta_\triangle I,
}
\]

with

\[
\boxed{
\delta_\triangle
=
1-\left(\frac{497}{500}\right)^2
=
\frac{2991}{250000}.
}
\tag{2DJ.1}
\]

The open problem is to connect this remainder to the finite-rank contact geometry.

---

## 2. Abstract setup

Let a pure state have coefficient matrix \(M\) with

\[
\operatorname{rank}M\le d.
\]

Let

\[
D=\sum_{j\ge1}D_j
\]

be its paired contact-block part, with mutually orthogonal left and right block supports. Define packet weights

\[
w_j=\|D_j\|_F^2,
\]

and let

\[
w_{(1)}\ge w_{(2)}\ge\cdots
\]

be their decreasing rearrangement.

Sprint 1221 gives the matched-block rank inequality

\[
\boxed{
\sum_{j>d}w_{(j)}
\le
\|M-D\|_F^2.
}
\tag{2DJ.2}
\]

The term \(M-D\) is the mass that cannot be held on paired contact packets by a rank-\(d\) state.

---

## 3. Positive-Remainder Finite-Rank Exit Theorem

Assume a positive remainder \(\mathcal R\succeq0\) obeys the service coercivity estimate

\[
\boxed{
\langle\psi,\mathcal R\psi\rangle
\ge
\delta\|M-D\|_F^2
}
\tag{2DJ.3}
\]

for some \(\delta>0\).

Then every rank-\(d\) state satisfies

\[
\boxed{
\langle\psi,\mathcal R\psi\rangle
\ge
\delta\sum_{j>d}w_{(j)}.
}
\tag{2DJ.4}
\]

### Proof

By (2DJ.3),

\[
\langle\psi,\mathcal R\psi\rangle
\ge
\delta\|M-D\|_F^2.
\]

By the matched-block theorem (2DJ.2),

\[
\|M-D\|_F^2
\ge
\sum_{j>d}w_{(j)}.
\]

Combining them proves (2DJ.4). ∎

This is the exact common core of the I3322 quantitative theorem and the proposed Yang–Mills application.

---

## 4. Packet-floor corollary

Suppose the moving contact packets satisfy

\[
\boxed{
w_{(j)}
\ge
a\,j^{-p}\Lambda^{-j}
}
\tag{2DJ.5}
\]

for all sufficiently large \(j\), where

\[
a>0,\qquad p\ge0,\qquad\Lambda>1.
\]

Then

\[
\begin{aligned}
\langle\psi,\mathcal R\psi\rangle
&\ge
\delta a
\sum_{j>d}j^{-p}\Lambda^{-j}\\
&\ge
\boxed{
\delta a\,
(d+1)^{-p}\Lambda^{-(d+1)}.
}
\end{aligned}
\tag{2DJ.6}
\]

Thus a rank-\(d\) state cannot approach the zero-remainder contact wall faster than exponentially in \(d\), up to a polynomial prefactor.

For \(p=4\),

\[
\boxed{
\epsilon_d
\ge
\delta a\,
(d+1)^{-4}\Lambda^{-(d+1)}.
}
\tag{2DJ.7}
\]

Consequently, reaching deficit at most \(\epsilon\) requires

\[
\boxed{
d
\ge
\frac{\log(1/\epsilon)}{\log\Lambda}
-
O(\log\log(1/\epsilon)).
}
\tag{2DJ.8}
\]

This is the logarithmic dimension-complexity law.

---

## 5. Exact Stage-2DI specialization

Take

\[
\mathcal R=\mathcal D_\triangle
=
I-L_\triangle^\ast L_\triangle.
\]

If the Yang–Mills contact packets can be chosen so that

\[
\boxed{
\langle\psi,\mathcal D_\triangle\psi\rangle
\ge
\frac{2991}{250000}
\|M-D\|_F^2,
}
\tag{2DJ.9}
\]

then every rank-\(d\) selector state obeys

\[
\boxed{
\epsilon_d^{\rm sel}
\ge
\frac{2991}{250000}
\sum_{j>d}w_{(j)}.
}
\tag{2DJ.10}
\]

With a packet floor

\[
w_{(j)}
\ge
a_{\rm YM}j^{-4}\Lambda_{\rm YM}^{-j},
\]

this becomes

\[
\boxed{
\epsilon_d^{\rm sel}
\ge
\frac{2991a_{\rm YM}}{250000}
(d+1)^{-4}
\Lambda_{\rm YM}^{-(d+1)}.
}
\tag{2DJ.11}
\]

This is a quantitative finite-rank selector-exit theorem.

---

## 6. What this changes immediately

Before this bridge, the next target was a strong corridor theorem:

\[
\text{every sufficiently long lawful path completes triangles at positive density}.
\]

The I3322 method permits a weaker target.

It is enough to prove:

1. a moving contact-packet decomposition for service-avoiding histories;
2. a lower envelope for the packet weights;
3. the coercivity relation (2DJ.9).

Then bounded-rank states are forced to exit the service-free contact orbit, even if some arbitrarily long formal paths exist.

Therefore:

\[
\boxed{
\textbf{positive-density recurrence is not necessary for excluding bounded-rank soft modes.}
}
\tag{2DJ.12}
\]

---

## 7. The exact YM dictionary

| I3322 wall proof | Yang–Mills selector program |
|---|---|
| Positive certificate remainders \(R_0,R_A,R_B\) | Triangle remainder \(I-L_\triangle^\ast L_\triangle\) |
| Equality/contact graph | Triangle-free attachment-history graph |
| Moving spectral packets | Moving owner/selector boundary packets |
| Schmidt dimension \(d\) | State Schmidt rank across the typed boundary |
| Finite-support exit | Matched-block rank exit |
| Geometric wall tail | Contact-packet weight tail |
| Dimension deficit \(c d^{-4}\Gamma^{-d}\) | Selector deficit \(c_{\rm YM}d^{-4}\Lambda_{\rm YM}^{-d}\) |
| Finite sections approach the wall | Finite boundary carriers approach the service-free wall |

---

## 8. The I3322 audit lessons that must be imported

The private quantitative campaign reportedly found and corrected four failure modes. Each has a direct YM counterpart.

### 8.1 Coarse address is not packet identity

A routing label, face address, or attachment type does not by itself identify one predictive packet. Packets must be quotiented by complete future receiver data.

### 8.2 Moving-frame multiplicity must be counted

Every owner embedding, reflection frame, and active selector orientation contributing the same coarse packet must be included in the packet norm and cardinality estimates.

### 8.3 The gap can vanish on inactive strata

The triangle remainder must not be assigned a fixed positive floor on degenerate or inactive sectors. Near saturation, the correct local estimate may be quadratic:

\[
\mathcal D_\triangle
\gtrsim
c\,\operatorname{dist}(\cdot,\mathcal Z)^2.
\]

### 8.4 Rank reduction must preserve the carrier

Any extremal or projective reduction used in the YM proof must preserve the relevant boundary Schmidt rank. A dilation that silently enlarges the carrier destroys the dimension conclusion.

---

## 9. What the bridge does not solve

The bound (2DJ.11) decays exponentially with the allowed rank \(d\).

If \(d\) is the full boundary carrier dimension and grows rapidly with cut width, this alone cannot yield a width-uniform mass gap.

The result is immediately powerful only if one proves one of:

1. the relevant Schmidt rank is uniformly bounded;
2. the effective packet rank grows slowly enough under RG;
3. triangle service recurs at positive density independently of \(d\);
4. the rank-dependent exit combines with another width-uniform coercive sector.

Thus the bridge can prove:

- exclusion of bounded-entanglement soft modes;
- a quantitative boundary-dimension witness;
- fixed-carrier exit;
- and potentially logarithmic resource complexity.

It does not by itself pass to infinite width.

---

## 10. Decisive next campaign

### Stage 2DK — Selector Contact Packet Construction

Construct the service-free contact relation from the exact selector modes

\[
T_{e,\alpha,h}.
\]

For every lawful continuation depth \(j\):

1. construct the predictive packet \(D_j\);
2. quotient coarse attachment addresses by future equivalence;
3. count every moving frame and multiplicity;
4. compute or bound \(w_j=\|D_j\|_F^2\);
5. test whether
   \[
   w_j\ge a_{\rm YM}j^{-4}\Lambda_{\rm YM}^{-j};
   \]
6. prove that \(M-D\) is serviced by the positive triangle remainder.

The key kill conditions are:

\[
w_j
\text{ has no uniform lower envelope},
\]

or

\[
\mathcal D_\triangle
\text{ fails to control }M-D.
\]

If both survive, the quantitative finite-rank exit theorem lands.
