# State-Anchored Defect Budgets and the Rank-Costed Clustering Gate

**Date:** 2026-08-05  
**Status:** four restriction-free lemmas proved; naive monotone removal killed;
matching converse reduced to a rank-costed clustering theorem.

---

## 1. Setup

Let a finite-dimensional strategy have Bell deficit

\[
\varepsilon
=
S-\langle\mathcal B_{3322}\rangle.
\]

Use the current limiting weld on its finite spectral support:

\[
SI-\mathcal B
=
R_0+R_A+R_B,
\qquad
R_\nu\succeq0,
\]

with

\[
\langle R_0\rangle+
\langle R_A\rangle+
\langle R_B\rangle
=
\varepsilon.
\]

Put

\[
X=A_1+A_2-I,
\qquad
U=B_1+B_2-I,
\]

and let \(\mu\) be the joint scalar spectral measure of \((X,U)\) in the state.

Write the scalar \(R_0\) symbol as

\[
\phi(x,u)\ge0.
\]

The two Bellman sums are

\[
P(x,u)=p(x)+g(u),
\]

\[
Q(x,u)=g(-x)+p(-u),
\]

and

\[
h(x,u)=S-d(x,u).
\]

Bellman feasibility gives

\[
0\le P,Q\le h,
\]

while

\[
\phi=h-\sqrt{PQ}.
\]

---

# Part I — Restriction-free scalar order budget

## 2. Individual Bellman slacks are paid by \(R_0\)

### Lemma 2.1

For every \((x,u)\),

\[
\boxed{
0\le h(x,u)-P(x,u)\le2\phi(x,u),
}
\]

\[
\boxed{
0\le h(x,u)-Q(x,u)\le2\phi(x,u).
}
\]

### Proof

Since \(Q\le h\),

\[
\sqrt{PQ}\le\sqrt{Ph}.
\]

Write \(t=P/h\in[0,1]\). Then

\[
\phi
\ge
h(1-\sqrt t)
\ge
\frac h2(1-t)
=
\frac12(h-P).
\]

The \(Q\) estimate is identical.

---

## 3. Pairwise approximate Monge theorem

For two points

\[
z_i=(x_i,u_i),
\qquad
\phi_i=\phi(z_i),
\]

the additive Bellman sum obeys

\[
P(x_1,u_1)+P(x_2,u_2)
=
P(x_1,u_2)+P(x_2,u_1).
\]

Using Lemma 2.1 on the own pairs and feasibility on the crossed pairs gives

\[
h(x_1,u_1)+h(x_2,u_2)
-
2(\phi_1+\phi_2)
\le
h(x_1,u_2)+h(x_2,u_1).
\]

For I3322,

\[
h(x_1,u_2)+h(x_2,u_1)
-
h(x_1,u_1)-h(x_2,u_2)
=
(x_1-x_2)(u_1-u_2).
\]

Therefore:

### Theorem 3.1 — Pointwise Monge-defect bound

\[
\boxed{
(x_1-x_2)(u_1-u_2)
\ge
-2(\phi_1+\phi_2).
}
\]

Equivalently,

\[
\boxed{
\bigl[(x_1-x_2)(u_1-u_2)\bigr]_-
\le
2(\phi_1+\phi_2).
}
\]

This is state-anchored and uses no spectral restriction.

---

## 4. Integrated inversion budget

Let \((X,U)\) and \((X',U')\) be independent samples from \(\mu\). Then:

### Corollary 4.1

\[
\boxed{
\mathbb E
\left[
\bigl((X-X')(U-U')\bigr)_-
\right]
\le
4\langle R_0\rangle
\le
4\varepsilon.
}
\]

Thus the total weighted order-inversion energy of the complete state is paid
directly by the scalar positive remainder.

This closes the restriction-free scalar part of I1.

---

# Part II — Restriction-free response budgets

## 5. Exact partition localization of the response defects

Let

\[
W=Y(B_3-I/2),
\qquad
W_B=(A_3-I/2)V,
\]

so that

\[
R_A=A(X)-W,
\qquad
R_B=B(U)-W_B,
\]

and

\[
Wf(X)=f(-X)W,
\qquad
W_Bf(U)=f(-U)W_B.
\]

Let \(\{E_i\}\) be any finite Borel partition of the \(X\)-spectrum. Then

\[
1_{E_i}(X)R_A\Omega
=
A(X)1_{E_i}(X)\Omega
-
W1_{-E_i}(X)\Omega.
\]

The left sides are mutually orthogonal. Hence:

### Theorem 5.1 — Alice response partition budget

\[
\boxed{
\sum_i
\left\|
A(X)1_{E_i}\Omega
-
W1_{-E_i}\Omega
\right\|^2
=
\|R_A\Omega\|^2.
}
\]

Since \(R_A\succeq0\),

\[
\|R_A\Omega\|^2
\le
\|R_A\|\langle R_A\rangle
\le
C_A\varepsilon
\]

for a uniform weld bound \(C_A\).

Likewise, for every finite Borel partition \(\{F_j\}\) of the \(U\)-spectrum:

### Theorem 5.2 — Bob response partition budget

\[
\boxed{
\sum_j
\left\|
B(U)1_{F_j}\Omega
-
W_B1_{-F_j}\Omega
\right\|^2
\le
C_B\varepsilon.
}
\]

These identities act on the whole state. No corridor compression and no
commutator term appears.

This closes the operator part of I1.

---

## 6. Endpoint service from an unmatched packet

Assume a packet corridor on which

\[
b(t)\ge b_->0,
\qquad
A(t)\le A_+.
\]

For one source cell \(E\), put

\[
z_-=\|1_{-E}(X)\Omega\|,
\qquad
z_+=\|1_E(X)\Omega\|,
\]

and

\[
e_E
=
\left\|
A(X)1_E\Omega
-
W1_{-E}\Omega
\right\|.
\]

Because

\[
\|W1_{-E}\Omega\|
\ge
b_-z_-,
\]

and

\[
\|A(X)1_E\Omega\|
\le
A_+z_+,
\]

the triangle inequality gives:

### Lemma 6.1

\[
\boxed{
b_-z_-
\le
A_+z_+
+
e_E.
}
\]

If the destination packet is unmatched, so \(z_+=0\), then

\[
e_E\ge b_-z_-.
\]

Summing over unmatched endpoints and using Theorem 5.1 gives

\[
\boxed{
\varepsilon
\ge
\frac{b_-^2}{C_A}
\sum_{\text{Alice-unmatched}}z_-^2.
}
\]

The Bob version is identical.

Therefore I4 is automatic after a rank-safe partial matching has been
constructed on a compact coefficient corridor.

---

# Part III — Maximizing-face stability

## 7. Compactness transfer theorem

Let \(K\) be a compact state space, let \(F:K\to\mathbb R\) be continuous and
affine, and let

\[
M=\{\omega:F(\omega)=S\}
\]

be the maximizing face.

Let \(G:K\to\mathbb R\) be continuous.

### Theorem 7.1 — Positive anchor stability

If

\[
\inf_{\omega\in M}G(\omega)\ge m>0,
\]

then there is \(\eta>0\) such that

\[
F(\omega)\ge S-\eta
\quad\Longrightarrow\quad
G(\omega)\ge\frac m2.
\]

### Proof

Otherwise there is a sequence \(\omega_n\) with

\[
F(\omega_n)\to S,
\qquad
G(\omega_n)<m/2.
\]

Compactness gives a convergent subsequence with limit \(\omega_\ast\in M\).
Continuity gives \(G(\omega_\ast)\le m/2\), contradiction.

### Theorem 7.2 — Null-sector stability

If \(G\ge0\) and

\[
G(\omega)=0
\qquad(\omega\in M),
\]

then for every \(\delta>0\), all sufficiently near-maximizing states satisfy

\[
G(\omega)<\delta.
\]

---

## 8. Conditional current-\(S\) consequence

Suppose the TT-030 exact scalar-orbit theorem is rebound to the repaired
current-\(S\) certificate and proves:

1. every exact maximizing state has the same scalar orbit measure, up to the
   declared Bell relabeling;
2. that orbit closure lies in one compact subinterval of \((-1,1)\);
3. a fixed continuous central packet observable has exact maximizing mass
   \(m_\ast>0\).

Then Theorem 7.1 gives a uniform near-maximizer packet-mass anchor

\[
\boxed{
m_0=\frac{m_\ast}{2}>0.
}
\]

Compact interiority gives uniform coefficient floors

\[
b_->0,
\qquad
r_->0.
\]

Thus, conditional on the current-\(S\) TT-030 rebind:

- I3 is closed;
- I5 is closed;
- I4 follows from Lemma 6.1 once the matching is extracted.

The remaining mathematical work is then entirely in I2.

This section is conditional because TT-030's current-\(S\) dependency rebind
must be audited separately; exact rigidity for an older or differently typed
certificate cannot be imported silently.

---

# Part IV — Why naive monotone removal fails

## 9. Exact two-packet counterexample

Fix \(\delta>0\). Put equal mass \(1/2\) on

\[
z_1=(0,\delta),
\qquad
z_2=(\delta,0).
\]

The two points are inverted:

\[
(x_1-x_2)(u_1-u_2)=-\delta^2.
\]

Assign scalar defects

\[
\phi(z_1)=\phi(z_2)=\frac{\delta^2}{4}.
\]

Then the pointwise Monge-defect inequality is satisfied exactly:

\[
-\delta^2
=
-2\left(
\frac{\delta^2}{4}
+
\frac{\delta^2}{4}
\right).
\]

The integrated scalar defect is

\[
\mathbb E\phi=\frac{\delta^2}{4}\to0.
\]

But every exactly monotone subset can retain at most one of the two packets, so
it has mass at most

\[
\frac12.
\]

Therefore:

\[
\boxed{
\text{small inversion energy}
\not\Rightarrow
\text{large-mass exact monotone subset}.
}
\]

The failure is caused by arbitrarily close crossing packets.

This kills a raw weighted-removal proof of I2.

---

## 10. Why clustering is the correct repair

The two packets above may be merged at coordinate resolution \(\delta\), but
their carrier cost must not disappear.

The correct object is therefore not an unweighted monotone chain. It is a
monotone chain of clusters with rank costs

\[
r_k
=
\operatorname{rank}(D_k),
\]

where \(D_k\) is the paired coefficient-matrix block of the cluster.

The matched-block theorem then supplies

\[
\sum_k r_k\le d
\]

for retained orthogonal clusters, while close spectral packets can be merged
without falsely declaring them to cost one dimension.

---

# Part V — The exact remaining theorem

## 11. Rank-Costed Monotone Clustering and Shifted-Forest Theorem

The next theorem must start from:

- the inversion budget of Corollary 4.1;
- the two response partition budgets of Theorems 5.1–5.2;
- the compactness anchor and transport floors;
- the coefficient-matrix rank budget.

It must construct clusters \(C_k\) satisfying:

1. **Ordered clustering**
   \[
   C_1<C_2<\cdots<C_N
   \]
   in both scalar coordinates after merging unresolved close crossings.

2. **Rank cost**
   \[
   r_k=\operatorname{rank}(D_k)\ge1,
   \qquad
   \sum_kr_k\le d.
   \]

3. **Mass retention**
   \[
   \sum_k\|D_k\|_F^2\ge m_0-o(1).
   \]

4. **Two decreasing partial matchings**
   induced by the Alice and Bob response budgets.

5. **Shifted-forest form**
   after deleting paid cycle/common-return mass, the union of the two matchings
   is a forest of alternating open paths.

6. **Approximate recurrence**
   along every retained path, with total squared error \(O(\varepsilon)\).

7. **Endpoint service**
   from Lemma 6.1.

Once these are established, the rank-costed version of the Robust Open-Chain
Exit Theorem gives the dimension lower profile.

---

## 12. First failed line

The first unproved implication is now exact:

\[
\boxed{
\begin{gathered}
\text{small weighted inversion energy}
+
\text{small response partition energy}
\\
\not\stackrel{\text{yet}}{\Longrightarrow}
\\
\text{large-mass rank-costed monotone shifted forest}.
\end{gathered}
}
\]

The missing ingredient is a clustering scale chosen from the state itself that:

- absorbs close crossing packets;
- preserves the operator response budgets;
- preserves paired-block orthogonality;
- and charges merged multiplicity through rank rather than packet count.

No spectral restriction is needed or permitted.

---

## 13. Revised E3 critical path

The converse program is now:

\[
\boxed{
\begin{array}{c}
\text{restriction-free scalar inversion budget}
\\
+
\\
\text{restriction-free response partition budgets}
\\
\downarrow
\\
\textbf{rank-costed monotone clustering}
\\
\downarrow
\\
\text{shifted alternating path forest}
\\
\downarrow
\\
\text{endpoint service + matched-block rank}
\\
\downarrow
\\
\text{dimension-dependent deficit}.
\end{array}
}
\]

The bold step is the only new load-bearing theorem.

---

## 14. Claim boundary

Proved here:

- individual Bellman slack bounds;
- pointwise and integrated Monge-defect bounds;
- exact restriction-free response partition budgets;
- endpoint service for unmatched packets;
- maximizing-face compactness transfer;
- an exact counterexample to naive monotone removal.

Conditionally closed after a current-\(S\) TT-030 rebind:

- uniform packet mass anchor;
- uniform transport floor.

Still open:

- rank-costed monotone clustering;
- shifted-forest extraction;
- the current matching lower exponent.
