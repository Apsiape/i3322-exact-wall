#!/usr/bin/env python3
from fractions import Fraction
import random

# 1. Correct epsilon^(1/8) order implication on exact rational surrogates.
# If 32 e^(1/8) >= L, then e >= (L/32)^8.
for n in range(1, 100):
    # choose r=e^(1/8) rational, L <= 32 r
    r = Fraction(n, 137)
    e = r**8
    for k in (1, 7, 16, 31, 32):
        L = k*r
        if Fraction(32)*r >= L:
            assert e >= (L/Fraction(32))**8

# 2. Top-d algebra: tail <= beta and total paired mass=1-beta => top d >= 1-2 beta.
rng = random.Random(230823)
for _ in range(20000):
    N = rng.randint(1, 18)
    d = rng.randint(1, N)
    nums = [rng.randint(0, 1000) for _ in range(N)]
    total_raw = sum(nums)
    if total_raw == 0:
        continue
    # Make paired mass <=1 and choose beta so tail condition holds.
    weights = [Fraction(x, total_raw*2) for x in nums]  # sum=1/2
    weights.sort(reverse=True)
    tail = sum(weights[d:])
    beta = max(tail, Fraction(1,2))  # paired total target 1-beta <= 1/2
    # rescale weights to sum exactly 1-beta if nonzero
    sw = sum(weights)
    if sw:
        weights = [w*(1-beta)/sw for w in weights]
        weights.sort(reverse=True)
    tail = sum(weights[d:])
    assert tail <= beta
    top = sum(weights[:d])
    assert top >= 1-2*beta

# 3. R1 contraction inequality in scalar 1D form (sharp model).
# |v-qTv| >= (1-q)|v| whenever |T|<=1.
for _ in range(50000):
    v = Fraction(rng.randint(1,1000), 997)
    q = Fraction(rng.randint(1,1000), 1000)
    T = Fraction(rng.randint(-1000,1000), 1000)
    lhs = abs(v-q*T*v)
    rhs = (1-q)*abs(v)
    assert lhs >= rhs

# 4. Exact F(q0) gap arithmetic.
Sminus = Fraction(2508753845015185, 10**16)
q0 = Fraction(889,1000)
Fq0 = Fraction(1,4) + (1-q0)**2/(16*q0)
gap = Sminus-Fq0
assert gap == Fraction(16308643699893,1778000000000000000)
assert gap > 0

print('PASS v23 repair guards')
print('epsilon root-taking implication: PASS')
print('top-d retained-mass algebra: PASS (20,000 exact-rational trials)')
print('R1 contraction inequality: PASS (50,000 exact-rational scalar trials)')
print('F(q0) exact gap:', gap)
print('NOTE: no claim of exhaustive 9x9 antitone enumeration is made by this guard.')
