# Variable-Gain Shifted-Forest Converse and Quantitative Cycle Payment

**Date:** 2026-08-05  
**Status:** exact abstract forest/cycle theorem retained; its former I3322 structural-gate ledger is superseded.  
**Supersedes:** the uniform-floor part of `RATE_TRICHOTOMY_AND_ROBUST_OPEN_CHAIN_CONVERSE.md`.

> **Correction notice.** The variable-gain forest estimate and quantitative cycle
> payment proved below remain valid. However, the claimed need for a separate
> rank-preserving shifted-flow decomposition is retired. The inherited antitone
> quantile theorem already removes branching, and the current monotone-completion
> atlas already supplies genuine response fundamental domains. The operative
> converse is now `TWO_SIDED_VARIABLE_GAIN_FUNDAMENTAL_DOMAIN_RANK_EXIT.md`.
> The later endpoint-margin and algebraic-closure theorems also eliminate corner
> tails and improve the exact multiplier bound to \(33/100<q<87/100\).

---

## 1. Main correction

The previous robust open-chain theorem assumed one uniform adjacent transport floor

\[
0<\sigma<1.
\]

That assumption is unnecessary and is poorly adapted to corner tails, where the exact current response gains may tend to zero.

The correct converse keeps the entire variable gain profile. It also uses the nearer serviced endpoint rather than propagating every packet to one predetermined endpoint. This improves the uniform-chain exponent and recovers the harmonic two-tail allocation law.

The quarter-ceiling tail gap supplies the complementary cycle receipt: a rounded response component that closes cannot be simultaneously near-current, scalar-small, and approximately multiplier-preserving.

---

# Part I — Variable-gain open paths

## 2. Rank-costed path forest

Let a finite-dimensional near-maximizer have Bell deficit

\[
\varepsilon=S-\langle\mathcal B_{3322}\rangle.
\]

Assume that, after paid deletions, it yields a finite forest of directed open paths. A path is written

\[
P=(v_0,v_1,\ldots,v_N).
\]

At vertex \(v_k\), let

\[
z_k\ge0
\]

be the packet amplitude and let

\[
r_k\in\mathbb N,
\qquad r_k\ge1,
\]

be its paired-block rank cost. Across the whole forest assume

\[
\sum_{P}\sum_{k\in P}r_k\le d
\]

and a retained state-mass anchor

\[
\sum_P\sum_{k\in P}z_k^2\ge m_0.
\]

Since every \(r_k\ge1\), the total number of retained vertices is at most \(d\).

---

## 3. Two-sided variable recurrence

For every edge \(k\leftrightarrow k+1\), assume positive local gains

\[
a_k>0,
\qquad
b_k>0,
\]

and nonnegative recurrence errors

\[
e_k^+,
\qquad e_k^-.
\]

The packet amplitudes obey

\[
\boxed{
 z_{k+1}\ge a_k z_k-e_k^+,
}
\]

\[
\boxed{
 z_k\ge b_k z_{k+1}-e_k^-.
}
\]

Assume the global response-defect budget

\[
\boxed{
\sum_P\sum_k\bigl((e_k^+)^2+(e_k^-)^2\bigr)
\le C_R\varepsilon.
}
\]

No uniform lower bound on \(a_k\) or \(b_k\) is imposed.

---

## 4. Variable endpoint service

For each path, assume its two unmatched endpoints are serviced with possibly path-dependent constants

\[
\delta_{P,-}>0,
\qquad
\delta_{P,+}>0,
\]

and that the global endpoint budget is

\[
\boxed{
\sum_P
\left(
\delta_{P,-}z_{P,0}^2+
\delta_{P,+}z_{P,N_P}^2
\right)
\le C_E\varepsilon.
}
\]

This is the correct form near physical endpoint corridors. The service constants are allowed to decay with the location of the terminal packet.

---

## 5. Path products and Green norms

Fix one path and one vertex \(k\).

Define the gain product from \(k\) to the left endpoint by

\[
G_{P,k}^-
=
\prod_{j=0}^{k-1}b_j,
\qquad
G_{P,0}^-=1,
\]

and the corresponding error Green norm

\[
E_{P,k}^-
=
\left[
\sum_{j=0}^{k-1}
\left(
\prod_{\ell=0}^{j-1}b_\ell
\right)^2
\right]^{1/2},
\]

where the empty product is one.

Define the gain product from \(k\) to the right endpoint by

\[
G_{P,k}^+
=
\prod_{j=k}^{N-1}a_j,
\qquad
G_{P,N}^+=1,
\]

and

\[
E_{P,k}^+
=
\left[
\sum_{j=k}^{N-1}
\left(
\prod_{\ell=j+1}^{N-1}a_\ell
\right)^2
\right]^{1/2}.
\]

Put

\[
B_{P,k}^-
=
\sqrt{\frac{C_E}{\delta_{P,-}}}
+
\sqrt{C_R}\,E_{P,k}^-,
\]

\[
B_{P,k}^+
=
\sqrt{\frac{C_E}{\delta_{P,+}}}
+
\sqrt{C_R}\,E_{P,k}^+,
\]

and define the serviced attenuation profile

\[
\boxed{
\Theta_{P,k}
=
\max\left\{
\frac{G_{P,k}^-}{B_{P,k}^-},
\frac{G_{P,k}^+}{B_{P,k}^+}
\right\}.
}
\]

Finally let

\[
\boxed{
\Theta_d
=
\min_{P,k}\Theta_{P,k}.
}
\]

---

## 6. Variable-Gain Rank-Costed Forest Theorem

### Theorem 6.1

Under the hypotheses above,

\[
\boxed{
\varepsilon
\ge
\frac{m_0}{d}\,\Theta_d^2.
}
\]

### Proof

Fix one path and one vertex \(k\). Iterating the backward recurrence gives

\[
z_0
\ge
G_{P,k}^-z_k
-
\sum_{j=0}^{k-1}
\left(
\prod_{\ell=0}^{j-1}b_\ell
\right)e_j^-.
\]

Cauchy--Schwarz and the global response budget imply

\[
G_{P,k}^-z_k
\le
z_0+
\sqrt{C_R\varepsilon}\,E_{P,k}^-.
\]

The endpoint budget gives

\[
z_0
\le
\sqrt{\frac{C_E\varepsilon}{\delta_{P,-}}}.
\]

Therefore

\[
\sqrt\varepsilon
\ge
\frac{G_{P,k}^-}{B_{P,k}^-}z_k.
\]

The forward recurrence and the right endpoint give similarly

\[
\sqrt\varepsilon
\ge
\frac{G_{P,k}^+}{B_{P,k}^+}z_k.
\]

Hence

\[
\sqrt\varepsilon
\ge
\Theta_{P,k}z_k
\ge
\Theta_d z_k
\]

for every retained vertex.

There are at most \(d\) retained vertices and their total squared amplitude is at least \(m_0\). Thus some vertex satisfies

\[
z_k^2\ge\frac{m_0}{d}.
\]

Substitution proves

\[
\varepsilon
\ge
\frac{m_0}{d}\Theta_d^2.
\qquad\square
\]

---

## 7. Uniform-gain corollary and exponent correction

Suppose on one path

\[
\sigma\le a_k,b_k\le1,
\qquad 0<\sigma<1,
\]

and both endpoint service constants are bounded below by \(\delta>0\).

Then the nearer endpoint is at graph distance at most \(N/2\). Consequently

\[
\Theta_{P,k}
\gtrsim
\sigma^{\lfloor N/2\rfloor}
\]

up to the explicit endpoint and Green denominators. Therefore

\[
\boxed{
\varepsilon
\gtrsim
\frac{1}{d}\sigma^d
}
\]

up to polynomial or bounded prefactors.

The earlier one-endpoint proof gave only \(d^{-1}\sigma^{2d}\). That exponent was not intrinsic; it came from propagating every anchor across the entire chain even though both endpoints were serviced.

---

## 8. Unequal-tail harmonic allocation

Assume the squared attenuation to the left endpoint behaves as

\[
\left(G_{P,k}^-\right)^2
=
\exp\bigl(-\kappa_- k+o(N)\bigr),
\]

while the squared attenuation to the right endpoint behaves as

\[
\left(G_{P,k}^+\right)^2
=
\exp\bigl(-\kappa_+(N-k)+o(N)\bigr).
\]

Ignoring subexponential endpoint/Green factors, the weakest serviced vertex balances

\[
\kappa_-k
=
\kappa_+(N-k).
\]

Thus

\[
k
=
\frac{\kappa_+}{\kappa_-+\kappa_+}N,
\]

and

\[
\boxed{
\Theta_d^2
=
\exp\bigl(-\kappa_{\rm eff}N+o(N)\bigr),
}
\]

where

\[
\boxed{
\kappa_{\rm eff}
=
\left(
\frac1{\kappa_-}
+
\frac1{\kappa_+}
\right)^{-1}.
}
\]

Therefore the variable-gain forest theorem has exactly the same harmonic allocation structure as the constructive two-boundary carrier.

A matching lower exponent no longer requires a uniform transport floor. It requires the extracted robust path products and endpoint-service factors to agree with the exact current carrier up to subexponential distortion.

---

# Part II — Quantitative cycle payment

## 9. Exact return threshold

Let

\[
q_0=\frac{889}{1000}
\]

and

\[
F(q)
=
\frac14+
\frac{(1-q)^2}{16q}.
\]

The current certified lower bound gives the exact positive gap

\[
\boxed{
\Delta_{\rm ret}
=
S_--F(q_0)
=
\frac{16308643699893}
{1778000000000000000}
>0.
}
\]

Numerically,

\[
\Delta_{\rm ret}
\approx9.172465523\times10^{-6}.
\]

Also

\[
1-q_0=\frac{111}{1000}.
\]

These two constants pay the two possible kinds of rounded cycle.

---

## 10. Abstract robust cycle receipts

Let a scalar-small rounded response cycle carry packet amplitude \(z\) and outward multiplier

\[
q\in(0,1].
\]

Assume two localized receipts.

### R1 — return mismatch

The composed response defects provide an error \(e_{\rm ret}\) satisfying

\[
\boxed{
(1-q)z\le e_{\rm ret}.
}
\]

### R2 — robust distorted-return Bell ceiling

For packets of scalar diameter at most \(h\), there is a modulus

\[
\omega(h)\downarrow0
\]

and a Bell-localization error \(e_{\rm Bell}\) such that

\[
\boxed{
\varepsilon_C
\ge
\bigl[S_--F(q)-\omega(h)\bigr]z^2
-e_{\rm Bell}z.
}
\]

Assume

\[
e_{\rm ret}^2+e_{\rm Bell}^2
\le C_C\varepsilon_C.
\]

R1 is the standard approximate-return inequality after composing the localized response maps. R2 is the robust scalar-small version of the exact closure calculation in the quantitative quarter-ceiling theorem.

---

## 11. Cycle Payment Theorem

### Theorem 11.1

Choose \(h_\ast>0\) so that

\[
\omega(h_\ast)\le\frac{\Delta_{\rm ret}}2.
\]

Every rounded response cycle of scalar diameter at most \(h_\ast\) satisfies

\[
\boxed{z^2\le C_{\rm cyc}\varepsilon_C}
\]

for an explicit constant depending only on \(C_C\) and the two rational return constants.

One admissible value is

\[
C_{\rm cyc}
=
\max\left\{
\frac{C_C}{(1-q_0)^2},
\frac{4}{\Delta_{\rm ret}}
\left(1+\frac{C_C}{\Delta_{\rm ret}}\right)
\right\}.
\]

### Proof

If

\[
q\le q_0,
\]

then R1 gives

\[
\frac{111}{1000}z
\le e_{\rm ret},
\]

so

\[
z^2
\le
\frac{C_C}{(1-q_0)^2}\varepsilon_C.
\]

If

\[
q\ge q_0,
\]

then \(F\) is decreasing on \((0,1]\), hence

\[
S_--F(q)-\omega(h)
\ge
\Delta_{\rm ret}-\frac{\Delta_{\rm ret}}2
=
\frac{\Delta_{\rm ret}}2.
\]

Thus

\[
\varepsilon_C
\ge
\frac{\Delta_{\rm ret}}2z^2-e_{\rm Bell}z.
\]

Young's inequality gives

\[
e_{\rm Bell}z
\le
\frac{\Delta_{\rm ret}}4z^2
+
\frac{e_{\rm Bell}^2}{\Delta_{\rm ret}}.
\]

Therefore

\[
\frac{\Delta_{\rm ret}}4z^2
\le
\varepsilon_C+
\frac{e_{\rm Bell}^2}{\Delta_{\rm ret}}
\le
\left(1+\frac{C_C}{\Delta_{\rm ret}}\right)\varepsilon_C.
\]

This proves the stated bound. \(\square\)

---

## 12. Why this does not revive coarse-cluster payment

The theorem pays a **cycle**, not a cluster.

A scalar-small cluster may still contain a long open response segment. Such a segment is not charged by the quarter ceiling. It survives as an open path and must be handled by rank cost, variable recurrence, and endpoint service.

Thus the correct dichotomy is

\[
\boxed{
\text{rounded component}
=
\text{paid cycle}
\quad\text{or}\quad
\text{rank-costed open path}.
}
\]

This is compatible with the known counterexample to coarse-cluster payment.

---

# Part III — Updated current-\(S\) converse ledger

## 13. Receipts already present

The current package now supplies more than the earlier clustering ledger recorded.
In particular, the shifted-grid theorem has already proved:

1. restriction-free integrated inversion control from \(R_0\);
2. removal of far inversions at a state-chosen grid scale;
3. strictly ordered near-conflict components;
4. mutually orthogonal paired matrix blocks;
5. recovery of total rank cost at most \(d\) by the matched-block theorem;
6. retained mass
   \[
   1-O(\varepsilon^{1/8});
   \]
7. exact antitone support for each response relation;
8. restriction-free Alice and Bob response partition budgets;
9. endpoint service for genuinely unmatched packets once the local coefficient
   factors are kept in the recurrence;
10. the exact quantitative quarter-ceiling return gap.

Thus rank-costed monotone clustering, block orthogonality, mass retention, and
response order are no longer open. The uniform transport-floor receipt is also
not structurally load-bearing after Theorem 6.1.

---

## 14. Supersession of the former structural gate

The shifted-flow theorem originally proposed here is not required. Antitone
transport is already one deterministic quantile reflection, and the current
monotone-completion atlas already unfolds the response into matched fundamental
domains. The operative rank-exit theorem is now the two-sided variable-gain
fundamental-domain theorem.

The only remaining asymptotic datum is the physical scalar compression of those
fundamental domains near the algebraic tail closures.

---

## 15. Corrected dependency ledger

The abstract forest theorem is no longer the load-bearing packetization route.
The current package now has:

1. unique antitone quantile response flow;
2. a monotone-completion translation coordinate;
3. matched response fundamental domains with disjoint source and target supports;
4. two-sided variable-gain rank exit without branch selection;
5. compact-interior tail closure and uniform coefficient bounds;
6. algebraic tail-closure quantization with \(33/100<q<87/100\).

Therefore the first open line is quantitative scalar compression near the
algebraic closure labels:

\[
\boxed{
\underline\Delta_d(h)
\ge
\text{a certified finite-order/exponential profile}.
}
\]

The forest/cycle theorem remains available for coarse discretizations, but it is
not required by the fundamental-domain converse.

---

## 16. Claim boundary

### Retained from this document

- the variable-gain rank-costed forest lower bound;
- variable endpoint-service handling;
- nearest-endpoint exponent improvement;
- harmonic unequal-tail allocation;
- the abstract quantitative cycle-payment theorem.

### Superseded

- rank-preserving shifted-flow decomposition as an independent gate;
- corner tails as a live current possibility;
- the \(889/1000\) bound as the best exact multiplier certificate.

### Current open target

- finite-order scalar response-domain compression at the algebraic closure labels;
- the final universal finite-dimensional lower profile.
