# Uniform Endpoint Collar — v23 Gate Record

**Date:** 2026-08-06  
**Verdict:** **OPEN; v22 endpoint-strip claim retracted.**

## 1. Retracted claim

`SHIFTED_GRID_RESPONSE_INTERFACE_REPAIR_V22.md` asserted that the promoted endpoint \(R_0\) gaps pay all mass in fixed endpoint strips:

\[
\mu(\text{endpoint strips})\le C_{\rm end}\varepsilon.
\]

The cited receipt proves a positive gap on the boundary **sets** \(x=\pm1\) or \(u=\pm1\), not a fixed-width collar. This implication is invalid and is retracted.

## 2. The theorem actually required by the antitone walk

To use a dimension-independent gain

\[
b_0=\inf_K b>0
\]

one needs a fixed \(w>0\) and \(c>0\), independent of strategy, local dimension, and near-critical level, such that the relevant scalar remainder satisfies

\[
\boxed{
\phi_n(x,u)\ge c
\quad\text{whenever}\quad
\max\{|x|,|u|\}\ge1-w.
}
\tag{2.1}
\]

Then endpoint-collar mass is \(O(\varepsilon)\), and all retained response coefficients live in a fixed compact interior corridor.

## 3. Why existing receipts do not prove (2.1)

The exact endpoint-line certificate gives uniform positive margins on the boundary set. The current zero-set theorem also excludes exact boundary atoms and exact zero-graph boundary closure. Neither statement supplies uniform equicontinuity of the near-critical symbols \(\phi_n\) as \(q_n\downarrow S\).

The dangerous coefficient is

\[
p_n(x)=\frac{b(x)^2}{g_n(x)}.
\]

Although \(g_n\ge q_n-S>0\), that lower bound degenerates with \(n\). Thus a fixed boundary-set gap plus pointwise continuity for each \(n\) does not yield a collar width uniform in \(n\).

This is exactly the boundary-layer failure mode already visible in the critical-storage audits.

## 4. What would close G1

Any one of the following is sufficient:

1. a direct uniform endpoint-collar lower bound (2.1);
2. a uniform boundary-layer estimate forcing \(p_n(x)\to0\) or another controlled endpoint limit uniformly over the near-critical family;
3. a replacement converse route whose gain product is allowed to approach the endpoint but still has a dimension-independent exponential lower class;
4. a current compact carrier theorem strong enough to show the entire load-bearing near-maximizer response walk remains in a fixed interior invariant corridor, with all leakage quantitatively paid.

No such receipt is certified in the v23 working set.

## 5. Status consequence

Until G1 is closed, the lower exponential converse cannot claim a dimension-independent \(\sigma>0\). Thus

\[
S-S_d\ge e^{-O(d)}
\]

remains conditional even though the antitone branch combinatorics is sound.
