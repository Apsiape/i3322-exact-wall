# Hostile Audit v23 — Refutation-First Verdict

**Date:** 2026-08-06  
**Verdict:** **MAJOR PARTIAL REPAIR; PROMOTION DENIED.**

## Audit question

Does the post-v22 repair package now prove

\[
S-S_d\ge\operatorname{poly}(d)^{-1}e^{-Cd}
\]

and therefore \(D(\varepsilon)=\Theta(\log(1/\varepsilon))\)?

**No.** The combinatorial/rank/typing core is substantially repaired, and the constructive upper direction is restored at existence-class strength, but two lower-bound analytic receipts remain genuinely open.

## A1. False rank-cost selection — repaired

**Attack:** v22 consumed \(\sum r_v\le d\), which is not implied by Sprint 1221.

**Repair:** keep shifted-grid §§1–6, then select the top \(d\) paired blocks by mass. Sprint 1221 gives

\[
\sum_{j>d}w_{(j)}\le\beta_{\rm far}.
\]

Result:

\[
N\le d,
\qquad
\beta_{\rm tot}\le2\beta_{\rm far}\le32\varepsilon^{1/8}.
\]

**Verdict:** PASS.

## A2. Simultaneous pairing — repaired

The shifted-grid connected components are jointly ordered: \(i<j\) implies both \(x<x'\) and \(u<u'\) for all cross-component points. Top-\(d\) deletion preserves this single global order. Alice and Bob packet families therefore use one common joint label order; no arbitrary permutation is available.

**Verdict:** PASS.

## A3. Incoming ownership — repaired

The false \(z_w\ge\zeta_{v\to w}\) step is removed. The exact destination identity yields

\[
z_w\ge
\frac{\zeta_{v\to w}-\|P_wr_A\|}{A_{\max}}.
\]

The additional residual is charged at most twice per block along a simple alternating walk.

**Verdict:** PASS.

## A4. Antitone branch combinatorics

No change. The edge budget and branch product remain sound:

\[
|E_A|+|E_B|\le4d-2,
\qquad
\prod D^{-1/2}\ge2^{-2d+1}.
\]

**Verdict:** PASS.

## A5. R1 return mismatch — restored

A selected projected two-step response return is a contraction channel \(T\). Current localized response equations give

\[
v-qTv=r_{\rm ret}.
\]

Therefore

\[
(1-q)\|v\|\le\|r_{\rm ret}\|.
\]

No null fixed-set multiplier equality is used.

**Verdict:** PASS as an operator lemma; downstream constants still require G1.

## A6. Exact F(q) theorem

The v22 exact scalar theorem remains intact:

\[
Q\le\frac{(1+q)^2}{16q}.
\]

The exact rational gap at \(q_0=889/1000\) is unchanged.

**Verdict:** PASS.

## A7. Robust cycle localization

**Attack:** can the selected packet return be converted, uniformly in rank/dimension, into the scalar F(q) inequalities with a Bell deficit owned by that packet?

**Result:** not yet. The noncommuting response terms in the Bell element generate cross terms under joint packet projection. v23 has not produced the explicit rank-independent modulus \(\omega(h)\) and Bell-localization inequality required by R2.

**Verdict:** FAIL / OPEN G2.

The old large-cycle Monge horn is retired. Large reflected 2-cycles are intended to be paid by F(q), which is global in \((x,u)\), but that still requires G2.

## A8. Endpoint strip

**Attack:** does a positive endpoint-set gap yield a fixed-width uniform near-critical collar?

**Result:** no proof. The near-critical reciprocal coefficient can develop a boundary layer as \(q\downarrow S\). v23 retracts the v22 strip claim.

**Verdict:** FAIL / OPEN G1.

## A9. Constructive upper

The old decimal coefficient is unsupported and retracted. However the current exact spatial carrier has strictly interior tail closures, endpoint transport ratios \(0<\rho_\pm<1\), and positive logarithmic tail exponents. The finite truncation theorem explicitly completes severed alternating blocks by one-dimensional projectors, preserving all six measurements as projections and the truncated state as a unit vector.

Thus

\[
D_{\rm upper}(\varepsilon)
\le
\kappa_{\rm eff}^{-1}\log(1/\varepsilon)+o(\log(1/\varepsilon))
\]

for an existential current \(\kappa_{\rm eff}>0\).

**Verdict:** PASS at existence-class strength; no decimal coefficient authorized.

## A10. Hygiene

- v22B cycle payment: RETIRED.
- v22 final hostile audit: RETRACTED.
- false rank-cost clustering: RETRACTED.
- v20 global route: RETIRED; its once-global X/U bridge remains reusable.
- VARIABLE_GAIN global forest route: RETIRED; its abstract R1/R2 cycle theorem is retained as a lemma.
- “forest” name removed from active route.
- \(\varepsilon^{1/8}\) inversion guard replaced by the actual order implication.
- old `13.2991468418` upper coefficient removed.

## Final verdict

The live frontier is now exactly

\[
\boxed{
G1:\ \text{uniform endpoint corridor/gain}
}
\]

and

\[
\boxed{
G2:\ \text{rank-independent robust Bell localization for }F(q).
}
\]

The structural distance to the lower logarithmic theorem is materially smaller, but promotion remains denied until both are closed.
