# Dependency Graph — v23 Antitone-Walk Converse

## Legend

- `[P]` promoted/current accepted receipt
- `[R]` repaired/proved in v23
- `[O]` open gate
- `[X]` retired/retracted

```text
[P] current weld / state-anchored inversion budget
        |
        v
[P] shifted-grid §§1–6
  far deletion + JOINT ordered components
        |
        +----------------------------+
        |                            |
        v                            v
[P] Sprint-1221 top-d theorem   [R] simultaneous-pairing receipt
        |                            |
        v                            |
[R] N<=d, beta_tot<=32 eps^(1/8) ---+
        |
        v
[P/R] exact reflection supports + once-global X/U bridge
        |
        v
[R] incoming ownership conversion
    sigma=b0/Amax
        |
        v
[R] antitone edge budget / single largest-component walk
        |
        +--------------------------+
        |                          |
        v                          v
[R] projected R1             [R] sink service
(1-q)z <= e_ret                   |
        |                          |
        +------------+-------------+
                     |
                     v
[P] exact F(q) distorted-return ceiling
                     |
                     v
[O] G2 robust Bell localization
                     |
                     v
[O] lower exponential converse

[O] G1 uniform endpoint corridor/gain
  ---------------------> incoming ownership / walk gain

Constructive upper branch:
[P] current spatial carrier
   -> [P] endpoint classification (E1)
   -> [P] endpoint-Cesaro ratios rho_± in (0,1)
   -> [P] alternating truncation + endpoint projectors
   -> [R] D_upper = O(log 1/eps)
```

## Retired nodes

```text
[X] v22B scalar-small compactness cycle payment
[X] v22 HOSTILE_AUDIT final PASS stamp
[X] rank-cost selection sum r_v <= d
[X] v22 fixed endpoint-strip claim
[X] v20 as a complete converse route
[X] VARIABLE_GAIN as a complete forest route
    (its abstract R1/R2 cycle lemma remains reusable)
[X] 13.2991468418 as a certified upper coefficient
[X] "forest" decomposition language
```

## Exact current promotion boundary

The upper logarithmic direction is restored. The lower logarithmic direction has exactly two live analytic gates:

1. **G1:** fixed current endpoint-excluded response corridor with dimension-independent coefficient floors;
2. **G2:** explicit rank-independent robust packet localization of the exact F(q) return ceiling, including Bell cross terms.
