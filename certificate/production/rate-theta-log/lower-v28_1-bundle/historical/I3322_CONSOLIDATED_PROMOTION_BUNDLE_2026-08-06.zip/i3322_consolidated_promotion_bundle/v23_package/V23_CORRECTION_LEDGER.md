# v23 Correction Ledger — after the v22 blind

**Date:** 2026-08-06

## Retractions

1. `CURRENT_TYPED_SCALAR_SMALL_CYCLE_PAYMENT_V22B.md` — **RETIRED / KILLED**. Scalar fixed return does not force neutral gain.
2. `HOSTILE_AUDIT_V22_FINAL.md` — **RETRACTED**. Its PASS stamp covered unproved cycle, clustering, localization, endpoint-collar, and upper-bound claims.
3. The shifted-grid rank-cost selection formula \(\sum r_v\le d\) — **RETRACTED**.
4. The v22 endpoint-strip implication from endpoint-set gaps — **RETRACTED**.
5. The decimal upper coefficient `13.2991468418` — **RETRACTED**.
6. The name “forest converse” — **RETIRED**. v23 follows one antitone walk; it does not construct a covering forest decomposition.

## Surviving v22 receipts

- antitone edge budget \(|E|\le m+n-1\);
- total branch-degree budget \(\sum D\le4d-2\) once \(N\le d\) is obtained lawfully;
- branch loss \(\prod D^{-1/2}\ge2^{-2d+1}\);
- exact response support reflection / zero-stays-zero;
- once-global X/U bridge;
- destination-localized SG2 identity;
- sink-service architecture;
- terminal trichotomy;
- exact distorted-return scalar ceiling \(F(q)\);
- exact return gap at \(q_0=889/1000\).

## New v23 repairs

### P2 — clustering

**CLOSED after correction.** Use shifted-grid §§1–6 only, then the true top-\(d\) matched-block inequality. This gives \(N\le d\), simultaneous joint ordering, and

\[
\beta_{\rm tot}\le32\varepsilon^{1/8}.
\]

No rank-cost sum is used.

### P3 — incoming ownership

**CLOSED.** The correct conversion is

\[
z_w\ge
\frac{\zeta_{v\to w}-\|P_wr_A\|}{A_{\max}},
\]

so

\[
\sigma=b_0/A_{\max}.
\]

The extra projected residual is globally \(\ell^2\)-cheap.

### P1/R1 — return mismatch

**CLOSED.** A localized two-step projected response channel is a contraction \(T\), and the current response equations give

\[
v-qTv=r_{\rm ret}.
\]

Hence

\[
(1-q)\|v\|\le\|r_{\rm ret}\|.
\]

### P1/R2 — robust Bell localization

**OPEN.** The exact \(F(q)\) theorem is sound, but a rank-independent packet-local modulus and Bell cross-term estimate have not been proved.

### P1(e) — non-inverted large 2-cycles

**Reduced to R2.** The global \(F(q)\) theorem applies at arbitrary \((x,u)\); no Monge sign is needed once robust packet localization is available.

### P4 — endpoint collar

**OPEN.** Fixed boundary-set gaps do not imply a uniform near-critical collar. The v22 strip claim is removed.

### P5 — upper bound

**REPAIRED at existence-class strength.** E1 follows from the current endpoint classification; endpoint-Cesàro transport gives \(\kappa_{\rm eff}>0\); alternating finite-section completion preserves all six projections. Therefore \(D_{\rm upper}=O(\log(1/\varepsilon))\). The decimal coefficient is not retained.

## Route status

The antitone-walk lower converse is now conditional on exactly two analytic receipts:

\[
\boxed{
\text{G1: uniform endpoint corridor/gain}
\quad+\quad
\text{G2: robust distorted-return Bell localization}.
}
\]

Until both close, the logarithmic lower bound and hence \(\Theta(\log)\) are **not promoted**.
