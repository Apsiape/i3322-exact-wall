#!/usr/bin/env python3
"""Finite exact guard for the minimum-point pseudo-cycle lemma.

This is a finite enumeration guard, not a proof substitute.  It checks every
nondecreasing self-map of grids of size 2..5 and every cyclic word of lengths
1..n, using the exact integer metric.
"""
from itertools import combinations_with_replacement, product

checks = 0
maps = 0
cycles = 0
for n in range(2, 6):
    grid = range(n)
    for values in combinations_with_replacement(grid, n):
        maps += 1
        f = tuple(values)
        for L in range(1, n + 1):
            for word in product(grid, repeat=L):
                cycles += 1
                delta = max(abs(word[(k + 1) % L] - f[word[k]]) for k in range(L))
                m = min(word)
                assert abs(f[m] - m) <= delta, (n, f, word, delta, m)
                checks += 1
print(f"PASS minimum-point pseudo-cycle guard: maps={maps}, cycles={cycles}, checks={checks}")
