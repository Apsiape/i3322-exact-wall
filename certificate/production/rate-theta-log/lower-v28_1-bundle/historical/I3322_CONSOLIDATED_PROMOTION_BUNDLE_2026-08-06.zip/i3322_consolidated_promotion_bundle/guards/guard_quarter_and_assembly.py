#!/usr/bin/env python3
"""Exact-rational guards for F(1), q0 gap, and the 33*eps^(1/8) bookkeeping."""
from fractions import Fraction as F

def Fq(q):
    return (1 + q) ** 2 / (16 * q)

assert Fq(F(1)) == F(1, 4)
q0 = F(889, 1000)
Sminus = F(2508753845015185, 10**16)
gap = Sminus - Fq(q0)
expected = F(16308643699893, 1778000000000000000)
assert gap == expected and gap > 0

# Put r=eps^(1/8). For 0<r<=1, eps=r^8 <= r, hence eps+32r<=33r.
# Exhaust a dense exact rational grid as a guard of the implemented inequality.
checks = 0
for k in range(1, 1001):
    r = F(k, 1000)
    eps = r ** 8
    assert eps <= r
    assert eps + 32 * r <= 33 * r
    checks += 1

print("PASS quarter/assembly guard")
print("  F(1)=1/4 exactly")
print(f"  S_- - F(889/1000) = {gap}")
print(f"  exact rational 33*r assembly checks={checks}")
