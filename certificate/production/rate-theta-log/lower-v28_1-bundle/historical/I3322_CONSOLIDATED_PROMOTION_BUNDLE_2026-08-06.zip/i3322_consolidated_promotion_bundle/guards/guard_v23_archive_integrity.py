#!/usr/bin/env python3
"""Verify extracted historical v23 files match the original v23 archive byte-for-byte."""
from pathlib import Path
from zipfile import ZipFile
import hashlib

root = Path(__file__).resolve().parents[1]
archive = root / "v23_package" / "current-S-antitone-walk-v23.ORIGINAL.zip"
extract_root = root / "v23_package"

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

with ZipFile(archive) as z:
    members = [n for n in z.namelist() if not n.endswith('/')]
    checked = 0
    for name in members:
        target = extract_root / name
        assert target.is_file(), f"missing extracted v23 member: {name}"
        assert sha(z.read(name)) == sha(target.read_bytes()), f"mismatch: {name}"
        checked += 1
print(f"PASS v23 archive integrity: members={checked}")
print(f"  original archive sha256={sha(archive.read_bytes())}")
