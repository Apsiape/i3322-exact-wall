#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys

root = Path(__file__).resolve().parent
scripts = [
    "guard_minimum_point_pseudocycle.py",
    "guard_g1_endpoint_arithmetic.py",
    "guard_quarter_and_assembly.py",
    "guard_prefix_product.py",
    "guard_v23_archive_integrity.py",
]
for name in scripts:
    print(f"=== {name} ===")
    subprocess.run([sys.executable, str(root / name)], check=True)
print("ALL CONSOLIDATED PROMOTION BUNDLE GUARDS PASSED")
