# Guard Scope

These scripts are exact-arithmetic or finite-enumeration **guards**, not theorem verifiers.

They check:

- the elementary minimum-point pseudo-cycle lemma on all small-grid monotone maps/cycles in the declared finite range;
- exact G1 endpoint contradiction arithmetic and separation of the two endpoint-rational provenance families;
- `F(1)=1/4`, the exact `q0=889/1000` rational gap, and the `33*epsilon^(1/8)` bookkeeping;
- the prefix degree-product inequalities used in Section 7 on exhaustive small integer budgets;
- byte-for-byte integrity of the extracted historical v23 package against the original archive.

They do **not** certify the five frozen analytic promotion gates. The promotion audit remains mandatory.
