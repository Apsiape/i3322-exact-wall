#!/usr/bin/env python3
"""Finite exact guard for the prefix degree-product inequalities used in Section 7."""
from math import prod

checks = 0
sequences = 0

def compositions(total, length, prefix=()):
    if length == 0:
        if total == 0:
            yield prefix
        return
    # positive parts
    for x in range(1, total - length + 2):
        yield from compositions(total - x, length - 1, prefix + (x,))

for d in range(1, 5):
    budget = 4 * d - 2
    maxlen = 2 * d
    for L in range(1, maxlen + 1):
        for total in range(L, budget + 1):
            for Ds in compositions(total, L):
                sequences += 1
                running = 1
                s = 0
                for D in Ds:
                    running *= D
                    s += D
                    assert D <= 2 ** D
                    assert running <= 2 ** s
                    assert s <= budget
                    assert running <= 2 ** budget
                    checks += 1
                assert prod(Ds) <= 2 ** budget

print(f"PASS prefix-product guard: sequences={sequences}, prefix_checks={checks}")
