# Current-S Alternating Packet Recurrence Typing

**Date:** 2026-08-06  
**Status:** exact operator-typing theorem, conditional only on the declared response-index maps of the current fundamental-domain atlas.  
**Purpose:** close F4 without identifying marginal propagation with direct joint-block transport.

---

## 1. Two parity families

Let

\[
\{E_n^{(0)}\}_{n\in\mathbb Z},
\qquad
\{E_n^{(1)}\}_{n\in\mathbb Z}
\]

be the two alternating marginal packet families. The current response atlas supplies index maps

\[
\alpha_0:\mathbb Z\to\mathbb Z,
\qquad
\alpha_1:\mathbb Z\to\mathbb Z
\]

such that

\[
\boxed{\alpha_1\circ\alpha_0(n)=n+1.}
\tag{1.1}
\]

The first family may be read on the \(U\)-marginal and the second on the \(X\)-marginal, or conversely, according to the chosen response orientation. No joint-block map is asserted here.

For \(k=0,1\), let

\[
R_k=A_k(T_k)-W_k
\]

be the relevant current response remainder, with

\[
W_k f(T_k)=f(-T_k)W_k,
\qquad
W_k^*W_k=b_k(T_k)^2.
\tag{1.2}
\]

The restriction-free partition identity gives

\[
\sum_n
\left\|
A_k(T_k)E_n^{(k)}\psi
-
W_kE_{\alpha_k(n)}^{(1-k)}\psi
\right\|^2
\le C_k\varepsilon.
\tag{1.3}
\]

---

## 2. One response step

Assume the packet corridor is compact interior and hence

\[
A_k(T_k)E_n^{(k)}\succeq a_kE_n^{(k)},
\qquad
b_k(T_k)E_{\alpha_k(n)}^{(1-k)}\preceq B_kE_{\alpha_k(n)}^{(1-k)},
\tag{2.1}
\]

with

\[
a_k>0,
\qquad
0<B_k<\infty.
\]

Put

\[
z_n^{(k)}=\|E_n^{(k)}\psi\|,
\]

\[
e_{k,n}=
\left\|
A_k(T_k)E_n^{(k)}\psi
-
W_kE_{\alpha_k(n)}^{(1-k)}\psi
\right\|.
\]

Using \(W_k^*W_k=b_k(T_k)^2\),

\[
\|W_kE_{\alpha_k(n)}^{(1-k)}\psi\|
\le B_k z_{\alpha_k(n)}^{(1-k)}.
\]

The reverse triangle inequality therefore gives

\[
a_kz_n^{(k)}
\le
B_kz_{\alpha_k(n)}^{(1-k)}+e_{k,n}.
\]

Hence

\[
\boxed{
z_{\alpha_k(n)}^{(1-k)}
\ge
\sigma_k z_n^{(k)}-f_{k,n},
}
\tag{2.2}
\]

where

\[
\sigma_k=\frac{a_k}{B_k}>0,
\qquad
f_{k,n}=\frac{e_{k,n}}{B_k}.
\]

Moreover,

\[
\sum_n f_{k,n}^2
\le
\frac{C_k}{B_k^2}\varepsilon.
\tag{2.3}
\]

---

## 3. Two-step response-domain recurrence

Apply (2.2) first with \(k=0\), then with \(k=1\). By (1.1),

\[
\begin{aligned}
z_{n+1}^{(0)}
&\ge
\sigma_1z_{\alpha_0(n)}^{(1)}-f_{1,\alpha_0(n)}\\
&\ge
\sigma_1\sigma_0z_n^{(0)}
-
\sigma_1f_{0,n}
-
f_{1,\alpha_0(n)}.
\end{aligned}
\]

Define

\[
\sigma=\sigma_0\sigma_1>0,
\]

\[
g_n=\sigma_1f_{0,n}+f_{1,\alpha_0(n)}.
\]

Then

\[
\boxed{
z_{n+1}^{(0)}\ge\sigma z_n^{(0)}-g_n.
}
\tag{3.1}
\]

Since \(\alpha_0\) is a packet permutation/injection on the retained path and

\[
(a+b)^2\le2a^2+2b^2,
\]

we obtain

\[
\boxed{
\sum_ng_n^2
\le
C_{\rm rsp}\varepsilon,
}
\tag{3.2}
\]

with

\[
C_{\rm rsp}
=
2\sigma_1^2\frac{C_0}{B_0^2}
+
2\frac{C_1}{B_1^2}.
\]

The reflected orientation gives the opposite-tail recurrence identically.

---

## 4. Separation from rank-visible blocks

Let

\[
D_n=F_nME_n^{\mathsf T},
\qquad
w_n=\|D_n\|_F^2
\]

be the matched joint blocks. The recurrence (3.1) concerns marginal amplitudes. Rank is introduced only through

\[
w_n\le (z_n^{(0)})^2
\]

and the one-time accounting

\[
\sum_n\left((z_n^{(0)})^2-w_n\right)
\le C_\beta\beta.
\tag{4.1}
\]

Thus:

\[
\boxed{
\text{response propagation is paid by }\varepsilon;
\quad
\text{marginal-to-joint conversion is paid once by }\beta.
}
\]

No \(\varepsilon+C\beta\) recurrence is used.

---

## 5. Current-I3322 application

For the current weld,

\[
W^*W=b(X)^2,
\qquad
W_B^*W_B=b(U)^2,
\]

and the Alice/Bob partition errors have total squared norm at most

\[
C_A\varepsilon+C_B\varepsilon.
\]

On every compact selected branch corridor and its hyperbolic tail closures, the coefficient functions are positive and continuous. Endpoint/terminal packets are handled separately by endpoint service. Hence the constants in (2.1) are uniform on every unpaid depth window.

Therefore F4 is closed once the current response atlas supplies (1.1), which is exactly the statement that two alternating response kernels advance one response fundamental domain.

---

## 6. Claim boundary

### Proved

- one-step marginal packet inequalities;
- exact two-step alternating recurrence;
- an \(O(\varepsilon)\) squared error budget;
- strict separation of marginal propagation from joint-block rank accounting.

### Not proved here

- the response-atlas index relation (1.1), consumed from the current monotone-completion/C034 rebind;
- finite-power scalar coercivity;
- any sharp longitudinal gain exponent.
