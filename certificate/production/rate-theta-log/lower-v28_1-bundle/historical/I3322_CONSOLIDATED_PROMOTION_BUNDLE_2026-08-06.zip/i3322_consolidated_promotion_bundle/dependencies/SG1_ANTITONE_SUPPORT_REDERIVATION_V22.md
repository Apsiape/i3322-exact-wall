# SG1 Antitone Support Rederivation — v22

**Date:** 2026-08-06  
**Status:** exact operator/order lemma.  
**Purpose:** rederive the shifted-grid antitone response support directly from the current reflection intertwiners and strict ordering of the retained paired blocks, so the v22 endgame does not depend on an unreplayed sentence in the historical clustering file.

---

## 1. Ordered paired blocks

Let the retained shifted-grid clustering produce paired block labels

\[
1<2<\cdots<N.
\]

On the X side let the corresponding mutually orthogonal spectral supports be
ordered scalar sets \(I_1,\ldots,I_N\), and on the U side let them be
\(J_1,\ldots,J_N\). `Strictly ordered` means that after fixing orientation,

\[
i<i'
\quad\Longrightarrow\quad
x<x'
\quad
(x\in I_i,\ x'\in I_{i'}),
\tag{1.1}
\]

and similarly for the \(J_i\).

The paired matrix blocks have these supports on the two sides and satisfy the
inherited rank ledger

\[
\sum_i r_i\le d.
\]

No response statement is used in this section.

---

## 2. Exact scalar reflection support

The current response intertwiners obey exactly

\[
Wf(X)=f(-X)W,
\qquad
W_Bf(U)=f(-U)W_B.
\tag{2.1}
\]

Therefore the ideal Alice response vector issued from an X packet \(I_i\) is
spectrally supported in

\[
-I_i:=\{-x:x\in I_i\},
\]

and the ideal Bob response vector issued from a U packet \(J_i\) is supported in
\(-J_i\).

The map

\[
t\mapsto-t
\]

is strictly decreasing. Hence

\[
i<i'
\quad\Longrightarrow\quad
-I_i\text{ lies strictly to the right of }-I_{i'}.
\tag{2.2}
\]

---

## 3. Alice antitone block relation

Declare an Alice support edge

\[
i\to_A j
\]

when the retained destination block \(j\) has nonzero X-side intersection with
the exact reflected support \(-I_i\) (equivalently, the corresponding projected
ideal response component is nonzero).

Suppose

\[
i<i',
\qquad
i\to_Aj,
\qquad
i'\to_Aj'.
\]

By (2.2), every point of \(-I_i\) is to the right of every point of
\(-I_{i'}\). Since the destination supports \(I_j\) are strictly ordered, a
nonzero intersection is possible only if

\[
\boxed{j\ge j'.}
\tag{3.1}
\]

If the retained destination blocks are distinct, the strict ordering gives
\(j>j'\).

Thus the Alice block support is antitone.

---

## 4. Bob antitone block relation

The identical argument with

\[
W_Bf(U)=f(-U)W_B
\]

and the strictly ordered U supports \(J_i\) gives

\[
\boxed{
i<i',\quad i\to_Bj,\quad i'\to_Bj'
\Longrightarrow j\ge j'.
}
\tag{4.1}
\]

Hence the Bob block support is antitone on the **same paired block label set**.

---

## 5. Why response error does not spoil SG1

The near-maximizer response equations compare the source vector with the ideal
reflected vector and contribute an error budget. They do not alter the spectral
support of the ideal vectors \(WE_i\psi\) or \(W_BE_i\psi\), which is fixed by
(2.1).

V22 defines the combinatorial response support from these ideal retained
components. Approximate response error appears only in the amplitude recurrence,
where it is paid by `SHIFTED_GRID_RESPONSE_INTERFACE_REPAIR_V22.md`.

Therefore support order and response error are cleanly separated:

\[
\boxed{
\text{SG1 antitone support is exact; SG2 carries the approximation budget.}
}
\]

---

## 6. Consequence

Both alternating response relations are antitone bipartite supports on at most
\(N\le d\) paired block vertices. Hence

\[
|E_A|+|E_B|\le4N-2\le4d-2
\]

by `ANTITONE_EDGE_BUDGET_AND_EXPONENTIAL_BRANCH_SELECTION_V22.md`.

No C034 atlas, current analytic graph rebind, or rank-preserving matching
decomposition is involved.
