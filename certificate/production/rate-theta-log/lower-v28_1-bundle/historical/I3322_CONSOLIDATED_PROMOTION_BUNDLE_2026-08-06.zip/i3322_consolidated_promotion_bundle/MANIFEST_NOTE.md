# Manifest Note

The single authoritative SHA-256 manifest is delivered **adjacent to the ZIP archive**, not embedded inside it. This is intentional: a manifest that contains the SHA-256 of the archive that itself contains that manifest would create a circular self-hash dependency.

`I3322_CONSOLIDATED_PROMOTION_BUNDLE_MANIFEST_SHA256.json` lists the SHA-256 and size of every ZIP member and the SHA-256/size of the completed ZIP itself.
