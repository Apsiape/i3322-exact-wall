# Dependency Receipt Index

This index names the local dependency copy supporting each consumed statement.

| Receipt | Local file | Scope consumed |
|---|---|---|
| Signed Theorem (N) authority / S interval / multiplicity-uniform quarter-ceiling provenance | `dependencies/THEOREM_N_SIGNED_PUBLIC_STATEMENT.md` | promoted nonattainment, `S>1/4`, dependency provenance |
| Round-3 audit source | `dependencies/THEOREM_N_ROUND3_BLIND_AUDIT_SOURCE.md` | closed-interval `3/2` Lipschitz derivation; exact `m_+`,`m_-`; multiplicity-after-norms audit |
| Canonical storage | `dependencies/CANONICAL_CRITICAL_STORAGE_AND_ANCESTRY.md` | canonical `g_S`; uniform `g_q -> g_S`; comparison `g_q>=g_S+(q-S)` |
| Reflection gluing / zero localization | `dependencies/CRITICAL_ZERO_SET_REDUCTION_FOR_THEOREM_N.md` | `g(t)g(-t)>=b(t)^2`; `R_0=0 => K(x)=K(u)=1`; zero equalities |
| Strict graph / dual-zero symmetry | `dependencies/CONVEX_ENVELOPE_PLATEAU_EXCLUSION_AND_THEOREM_N_COMPLETION.md` | strict full-zero graph `x=P(u)`; `R_0(-u,-x)=R_0(x,u)` |
| Endpoint-line inactivity rationals | `dependencies/REFLECTION_DUAL_UPPER_ENVELOPE_AND_ADAPTIVE_TAILS.md` | exact provenance for `4039/100000`, `9893/50000` |
| Response localized identities / deleted destinations / bridge | `dependencies/SHIFTED_GRID_RESPONSE_INTERFACE_REPAIR_V22.md` | response partitions, deletion payment, once-global X/U bridge |
| Exact reflection support / antitone typing | `dependencies/SG1_ANTITONE_SUPPORT_REDERIVATION_V22.md` | reflected packet supports; common-label antitone relations |
| Incoming state-amplitude ownership | `dependencies/INCOMING_OWNERSHIP_AND_TYPED_RECURRENCE_V23.md` | lawful recurrence and global square-summable response error |
| Marginal/joint one-time accounting | `dependencies/CURRENT_S_ALTERNATING_PACKET_RECURRENCE_TYPING.md` | `w_n<=z_n^2` and one-time marginal-to-joint loss; response partition errors |
| Top-d simultaneous clustering | `dependencies/TOP_D_SIMULTANEOUS_MONOTONE_CLUSTERING_V23.md` | `N<=d`; `beta_tot<=32 eps^(1/8)`; common paired labels |
| Antitone edge budget | `dependencies/ANTITONE_EDGE_BUDGET_AND_EXPONENTIAL_BRANCH_SELECTION_V22.md` | edge count, prefix degree budget, `e^{-O(d)}` branch theorem |
| R1 | `dependencies/PROJECTED_RETURN_MISMATCH_R1_V23.md` | distorted-gain service only |
| Exact distorted-return formula | `dependencies/DISTORTED_RETURN_QUARTER_CEILING_CURRENT_V22.md` | `F(q)=(1+q)^2/(16q)` and `F(1)=1/4` |
| Exact common-return/spatial response grammar | `dependencies/CURRENT_S_SPATIAL_ATTAINMENT_THEOREM.md` and `CURRENT_S_SPATIAL_ATTAINMENT_BY_SCALAR_ORBIT.md` | increasing `tau`, fixed/common-return component equations |
